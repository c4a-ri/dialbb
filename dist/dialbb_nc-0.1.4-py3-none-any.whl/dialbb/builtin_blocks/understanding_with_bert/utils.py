#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# utils.py
#   utility functions for bert

__version__ = '0.1'
__author__ = 'Mikio Nakano'
__copyright__ = 'C4A Research Institute, Inc.'

import os
import random
import logging
from typing import Dict, List, Any, Tuple
import yaml
from dotmap import DotMap

import torch
import numpy as np
from seqeval.metrics import precision_score, recall_score, f1_score
from transformers import BertConfig, DistilBertConfig, AlbertConfig
from transformers import BertJapaneseTokenizer, DistilBertTokenizer
from transformers import AlbertTokenizer

from dialbb.builtin_blocks.understanding_with_bert.model import JointBERT, JointDistilBERT, JointAlbert
from dialbb.util.error_handlers import abort_during_building

logger = logging.getLogger(__name__)

MODEL_CLASSES = {
    'bert': (BertConfig, JointBERT, BertJapaneseTokenizer),
    'distilbert': (DistilBertConfig, JointDistilBERT, DistilBertTokenizer),
    'albert': (AlbertConfig, JointAlbert, AlbertTokenizer)
}

MODEL_PATH_MAP = {
    'bert': 'cl-tohoku/bert-base-japanese-whole-word-masking',
    'distilbert': 'distilbert-base-uncased',
    'albert': 'albert-xxlarge-v1'
}


def read_config(config_file: str) -> DotMap:
    """
    read config file of application
    :param file name of configuration
    :return configuration data in DotMap format
    """
    logger.info(f"reading application config file. name={config_file}")

    # read config file
    try:
        with open(config_file, encoding='utf-8') as file:
            config: Dict[str, Any] = yaml.safe_load(file)
    except Exception as e:
        raise abort_during_building(
            f"can't read config file: {config_file}. " + str(e))

    # convert DotMap format
    return DotMap(config, _dynamic=False)


def get_intent_labels(args: DotMap) -> List[str]:
    """
    read intent label file
    :param configuration of application
    :return type list
    """
    return [label.strip() for label in open(os.path.join(args.app_dir,
            args.data_dir, args.intent_label_file), 'r', encoding='utf-8')]


def get_slot_labels(args: DotMap) -> List[str]:
    """
    read slot label file
    :param configuration of application
    :return slot list
    """
    return [label.strip() for label in open(os.path.join(args.app_dir,
            args.data_dir, args.slot_label_file), 'r', encoding='utf-8')]


def load_tokenizer(args: DotMap) -> Tuple[str]:
    """
    get a tokenizer to be used
    :param configuration of application
    :return target Tokenizer
    """
    return MODEL_CLASSES[args.model_type][2].from_pretrained(args.base_model_name)


def get_device(args: DotMap) -> str:
    """
    get a processer type to be used
    :param configuration of application
    :return processer type
    """
    return "cuda" if torch.cuda.is_available() and not args.no_cuda else "cpu"


def init_logger(logLvl) -> None:
    """
    initial Logging for simple mode
    :param log level
    """
    logging.basicConfig(format='%(message)s',
                        level=logging.getLevelName(logLvl))


def init_logger_detail(logLvl) -> None:
    """
    initial Logging for detail mode
    :param log level
    """
    logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s -   %(message)s',
                        datefmt='%m/%d/%Y %H:%M:%S',
                        level=logging.getLevelName(logLvl))


def set_seed(args: DotMap) -> None:
    """
    set seed
    :param configuration of application
    """
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if not args.no_cuda and torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)


def compute_metrics(intent_preds, intent_labels, slot_preds, slot_labels) -> Dict[str, Any]:
    """
    compute metrics
    :param intent predictions
    :param intent labels
    :param slot predictions
    :param slot labels
    :return calculation results
    """
    assert len(intent_preds) == len(intent_labels) == len(
        slot_preds) == len(slot_labels)
    results = {}
    intent_result = get_intent_acc(intent_preds, intent_labels)
    slot_result = get_slot_metrics(slot_preds, slot_labels)
    sementic_result = get_sentence_frame_acc(
        intent_preds, intent_labels, slot_preds, slot_labels)

    results.update(intent_result)
    results.update(slot_result)
    results.update(sementic_result)

    return results


def get_slot_metrics(preds, labels) -> Dict[str, Any]:
    """
    get slot metrics
    :param slot predictions
    :param slot labels
    :return formatting results
    """
    assert len(preds) == len(labels)
    return {
        "slot_precision": precision_score(labels, preds),
        "slot_recall": recall_score(labels, preds),
        "slot_f1": f1_score(labels, preds)
    }


def get_intent_acc(preds, labels) -> Dict[str, Any]:
    """
    get intent acc
    :param intent predictions
    :param intent labels
    :return formatting results
    """
    acc = (preds == labels).mean()
    return {
        "intent_acc": acc
    }


def get_sentence_frame_acc(intent_preds, intent_labels, slot_preds, slot_labels) -> Dict[str, Any]:
    """
    For the cases that intent and all the slots are correct (in one sentence)
    :param intent predictions
    :param intent labels
    :param slot predictions
    :param slot labels
    :return formatting results
    """
    # Get the intent comparison result
    intent_result = (intent_preds == intent_labels)

    # Get the slot comparision result
    slot_result = []
    for preds, labels in zip(slot_preds, slot_labels):
        assert len(preds) == len(labels)
        one_sent_result = True
        for p, l in zip(preds, labels):
            if p != l:
                one_sent_result = False
                break
        slot_result.append(one_sent_result)
    slot_result = np.array(slot_result)

    sementic_acc = np.multiply(intent_result, slot_result).mean()
    return {
        "sementic_frame_acc": sementic_acc
    }
