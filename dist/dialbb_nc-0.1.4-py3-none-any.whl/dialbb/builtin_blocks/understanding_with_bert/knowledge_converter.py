#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# knowledge_converter.py
#   convert nlu knowledge to BERT training data format

__version__ = '0.1'
__author__ = 'Mikio Nakano'
__copyright__ = 'C4A Research Institute, Inc.'

import re
import os
import logging
from typing import List, Tuple
import pandas as pd
from pandas import DataFrame
import json

from dialbb.util.error_handlers import abort_during_building

logger = logging.getLogger(__name__)

# sheet names
UTTERANCE_SHEET: str = "utterances"
SLOTS_SHEET: str = "slots"
ENTITIES_SHEET: str = "entities"
DICTIONARY_SHEET: str = "dictionary"

# column names
COLUMN_FLAG: str = "flag"
COLUMN_TYPE: str = "type"
COLUMN_UTTERANCE: str = "utterance"
COLUMN_SLOT_NAME: str = "slot name"
COLUMN_ENTITY_CLASS: str = "entity class"
COLUMN_USE_SYNONYMS: str = "use synonyms"
COLUMN_AUTOMATICALLY_EXTENSIBLE: str = "automatically extensible"
COLUMN_MATCHING_STRICTNESS: str = "matching strictness"
COLUMN_ENTITY: str = "entity"
COLUMN_SYNONYMS: str = "synonyms"

# define values
VALUE_FLAG_ON: str = "Y"
VALUE_YES: str = "yes"


def read_knowledge_data(file_name: str) -> DataFrame:
    """
    Read knowledge description file
    :param knowledge file name
    """
    logger.info(f"reading spreadsheet: {file_name}")
    # read excel to DataFrame
    try:
        df = pd.read_excel(file_name, sheet_name=None)
    except Exception as e:
        abort_during_building(f"failed to read spreadsheet: {file_name}. {str(e)}")

    return df


def get_types(df: DataFrame) -> List[str]:
    """
    Extract type list
    :param knowledge data
    """
    # Create a list of type columns
    types = df[UTTERANCE_SHEET][COLUMN_TYPE].values
    logger.debug(types)

    return types.tolist()


def get_utterance(df: DataFrame, tokenizer) -> Tuple[List[str], List[str]]:
    """
    Extract sentence text
    :param knowledge data
    :param tokenizer
    :return separated words
    :return corresponding labels
    """
    text_list = []        # List of study texts
    encoded_text_list = []  # List of encoded sentences (converted to word IDs)
    split_text_list = []  # List of sentences broken down by word
    entities_list = []    # List of names and labels
    labels_list = []      # List of BIO labels for sentences

    # Annotation Regular Expression Patterns
    pat = re.compile(u'\(([\w:]+)\)\[(\w+)\]', re.U)
    # Create a list of utterance columns
    for text in df[UTTERANCE_SHEET][COLUMN_UTTERANCE].values:
        logger.debug(text)
        items = []
        for m in pat.finditer(text):
            # Set word and label pairs into tuples
            tp = (m.group(1), m.group(2))
            items.append(tp)
        if len(items) == 0:
            items.append(('', ''))
        entities_list.append(items)
        # Remove annotation
        plain_text = re.sub(r'[\(\)]', '', text)
        plain_text = re.sub(r'\[\w+\]', '', plain_text)
        text_list.append(plain_text)

    # Encode/decode text and save
    for text in text_list:
        encoded_text = tokenizer(text, add_special_tokens=False)
        encoded_text_list.append(encoded_text)
        split_text = tokenizer.decode(encoded_text["input_ids"]).split()
        split_text_list.append(split_text)
        labels_list.append(["O"] * len(split_text))

    # Initialization of eigenexpression extraction labels
    unique_labels = set("O")
    found_named_entity = False

    # Assign a BIO label to each word based on annotations
    for sample_idx, (encoded_text, split_text, entities) in enumerate(zip(encoded_text_list,
                                                                      split_text_list, entities_list)):
        if len(entities) == 0:
            continue
        target_entity = entities.pop(0)
        entity_name = target_entity[0]
        entity_label = target_entity[1]
        for word_idx, word in enumerate(split_text):
            # Assigning ignore labels to special tokens
            if word == "[CLS]" or word == "[SEP]" or word == "[PAD]":
                labels_list[sample_idx][word_idx] = "IGNORE"
                continue

            if entity_name.startswith(word):
                if entity_name.endswith(word):
                    label = f"B-{entity_label}"
                    labels_list[sample_idx][word_idx] = label
                    unique_labels.add(label)

                    if len(entities) >= 1:
                        target_entity = entities.pop(0)
                        entity_name = target_entity[0]
                        entity_label = target_entity[1]

                else:
                    for word_idx_2 in range(word_idx + 1, len(split_text)):
                        if "".join(split_text[word_idx: word_idx_2 + 1]) not in \
                                entity_name.replace(" ", "").replace("　", ""):
                            found_named_entity = False
                            break
                        if entity_name.endswith(split_text[word_idx_2]):
                            labels = [f"B-{entity_label}"] + \
                                [f"I-{entity_label}"] * (word_idx_2 - word_idx)
                            unique_labels |= set(labels)
                            labels_list[sample_idx][word_idx: word_idx_2 + 1] = labels
                            found_named_entity = True
                            break
                    if found_named_entity:
                        if len(entities) >= 1:
                            target_entity = entities.pop(0)
                            entity_name = target_entity[0]
                            entity_label = target_entity[1]

    return split_text_list, labels_list


def save_knowledge_data(types: List[str], texts: List[str], labels: List[str], save_dir: str) -> None:
    """
    Save knowledge data to files
    :param list of types
    :param list of texts
    :param list of labels
    :param a directory of the knowledge data
    """
    # save directory check
    if not os.path.exists(save_dir):
        # create directory
        os.makedirs(save_dir)
    # save to files
    with open(save_dir+'/label', 'w', encoding='utf-8') as f:
        # add last line
        types.append('')
        f.write('\n'.join(types))
    with open(save_dir+'/seq.in', 'w', encoding='utf-8') as f:
        for line in texts:
            f.write(' '.join(line) + '\n')
    with open(save_dir+'/seq.out', 'w', encoding='utf-8') as f:
        for line in labels:
            f.write(' '.join(line) + '\n')


def vocab_process(intent_label_vocab: str, slot_label_vocab: str, data_dir: str) -> None:
    """
    Create and save a unique list
    :param Intent Label file name
    :param Slot Label file name
    :param a directory of the knowledge data
    """
    train_dir = os.path.join(data_dir, 'train')
    # intent
    with open(os.path.join(train_dir, 'label'), 'r', encoding='utf-8') as f_r, \
         open(os.path.join(data_dir, intent_label_vocab), 'w', encoding='utf-8') as f_w:
        intent_vocab = set()
        for line in f_r:
            line = line.strip()
            intent_vocab.add(line)

        additional_tokens = ["UNK"]
        for token in additional_tokens:
            f_w.write(token + '\n')

        intent_vocab = sorted(list(intent_vocab))
        for intent in intent_vocab:
            f_w.write(intent + '\n')

    # slot
    with open(os.path.join(train_dir, 'seq.out'), 'r', encoding='utf-8') as f_r, \
         open(os.path.join(data_dir, slot_label_vocab), 'w', encoding='utf-8') as f_w:
        slot_vocab = set()
        for line in f_r:
            line = line.strip()
            slots = line.split()
            for slot in slots:
                slot_vocab.add(slot)

        slot_vocab = sorted(list(slot_vocab), key=lambda x: (x[2:], x[:2]))

        # Write additional tokens
        additional_tokens = ["PAD", "UNK"]
        for token in additional_tokens:
            f_w.write(token + '\n')

        for slot in slot_vocab:
            f_w.write(slot + '\n')


def createSynonyms(df: DataFrame, synonyms_list: str, save_dir: str) -> None:
    """
    Create a synonyms list file
    :param knowledge data
    :param Synonyms list file
    :param a directory of the knowledge data
    """
    # Extract valid only
    df_slots = df[SLOTS_SHEET][df[SLOTS_SHEET][COLUMN_FLAG] == VALUE_FLAG_ON]
    df_entities = df[ENTITIES_SHEET][df[ENTITIES_SHEET][COLUMN_FLAG] == VALUE_FLAG_ON]
    df_dictionary = df[DICTIONARY_SHEET][df[DICTIONARY_SHEET][COLUMN_FLAG] == VALUE_FLAG_ON]

    # Expanding synonyms
    synonym_tabel = {}
    for _, sl in df_slots.iterrows():
        synonym_list = {}
        slot = sl[COLUMN_SLOT_NAME]
        logger.debug(f'slot:{slot}')

        # Get Entity from Slot
        entities = df_entities[(df_entities[COLUMN_ENTITY_CLASS] == sl[COLUMN_ENTITY_CLASS]) &
                               (df_entities[COLUMN_USE_SYNONYMS] == VALUE_YES)]

        for _, et in entities.iterrows():
            # Get Synonyms from Entity
            synonyms = df_dictionary[df_dictionary[COLUMN_ENTITY_CLASS] == et[COLUMN_ENTITY_CLASS]]

            # Create Synonyms and Entity pairs
            for _, sy in synonyms.iterrows():
                logger.debug('value:{} synonyms:{}'.format(sy[COLUMN_ENTITY], sy[COLUMN_SYNONYMS]))
                for synonym in re.split(u'[、,]', sy[COLUMN_SYNONYMS]):
                    synonym_list[synonym] = sy[COLUMN_ENTITY]

        synonym_tabel[slot] = synonym_list

    logger.debug(f'synonym_tabel{synonym_tabel}')

    # Save Synonym and Entity pairs in json files
    with open(os.path.join(save_dir, synonyms_list), 'w', encoding='utf-8') as f:
        json.dump(synonym_tabel, f, ensure_ascii=False)
