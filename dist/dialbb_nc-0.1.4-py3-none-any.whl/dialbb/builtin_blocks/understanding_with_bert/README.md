BERT言語理解モジュールの導入方法
=================

利用事前学習モデル
-----------------
* BERT 「cl-tohoku/bert-base-japanese-whole-word-masking」
* トークナイザー「BertJapaneseTokenizer」

学習データ生成処理
-----------------
* 知識記述ファイル：sample-knowledge-ja.xlsx
* クロスバリデーション
  * 学習データ：70%
  * 評価データ：20%
  * テストデータ：10%

ファインチューニング処理
-----------------
* 学習データを読み込みファインチューニングを実施
* 文書分類とスロット抽出を同時にトレーニング
* 指定ポイントで評価・テストを実施
* 生成したモデルはConfigで指定されたディレクトリにセーブ

リリースファイル
-----------------
|フォルダ | ファイル | 内容 |
|---------|---------|------------|
|dialbb/builtin_blocks/understanding_with_bert/ |bert_model_creator.py|ファインチューニングメイン処理|
|dialbb/builtin_blocks/understanding_with_bert/ |knowledge_converter.py|知識記述読み込み処理|
|dialbb/builtin_blocks/understanding_with_bert/ |data_loader.py|学習データ変換処理|
|dialbb/builtin_blocks/understanding_with_bert/ |trainer.py|トレーニング実行|
|dialbb/builtin_blocks/understanding_with_bert/ |utils.py|ユーティリティ群|
|dialbb/builtin_blocks/understanding_with_bert/ |bert_understander.py|BERT言語理解処理|
|dialbb/builtin_blocks/understanding_with_bert/model |module.py|BERTモデル生成処理|
|dialbb/builtin_blocks/understanding_with_bert/model |modeling_xxx.py|各種モデル定義|
|sample_apps/network_ja|config_bert.yml|BERT用Configファイル|
|sample_apps/network_ja|bert_training_param.yml|BERTモデル学習パラメータ|

モデル作成手順
-----------------
### [環境構築]  
1. Python3が使える事（動作確認はver3.12）  
1. requiremenets.txtに記述されているpythonライブラリをインストール  
1. 形態素解析用にunidicがインストールされていること（python -m unidic download）

### [実行手順]  
1. モデルの作成  
  \$ cd dialbb-dev  
  \$ python dialbb/builtin_blocks/understanding_with_bert/bert_model_creator.py sample_apps/network_ja/bert_training_param.yml

### [生成データ]
* 学習データ　…知識記述ファイルのutterrancesシートからファインチューニング用に変換したテキストデータ  
  /sample_apps/network_ja/data_bert/配下
* BERTモデル　…学習データから生成したJointBERTモデル  
  /sample_apps/network_ja/model_bert/配下

BERT言語理解による日本語アプリの起動方法
-----------------
　　\$ python run_server.py sample_apps/network_ja/config_bert.yml
