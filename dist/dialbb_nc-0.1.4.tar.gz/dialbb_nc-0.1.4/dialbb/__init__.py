from dialbb.main import DialogueProcessor
from dialbb.abstract_block import AbstractBlock
