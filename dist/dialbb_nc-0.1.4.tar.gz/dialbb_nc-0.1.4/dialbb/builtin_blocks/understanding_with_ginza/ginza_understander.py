#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# ginza_understander.py
#   understand input text using GiNZA

__version__ = '0.1'
__author__ = 'Mikio Nakano'
__copyright__ = 'C4A Research Institute, Inc.'


from dialbb.abstract_block import AbstractBlock
from typing import List, Any, Dict, Tuple

import spacy
from spacy import displacy

class Understander(AbstractBlock):

    def __init__(self, *args):
        super().__init__(*args)
        # 相対日付のパターン定義
        self.patterns = [
            {'label': 'Date', 'pattern': '昨日'},
            {'label': 'Date', 'pattern': 'きのう'},
            {'label': 'Date', 'pattern': '今日'},
            {'label': 'Date', 'pattern': '明日'},
            {'label': 'Date', 'pattern': 'あした'},
            {'label': 'Date', 'pattern': '明後日'},
            {'label': 'Date', 'pattern': 'あさって'},
            {'label': 'Date', 'pattern': '一昨日'},
            {'label': 'Date', 'pattern': 'おととい'},
            {'label': 'Date', 'pattern': '先週'},
            {'label': 'Date', 'pattern': '今週'},
            {'label': 'Date', 'pattern': '来週'},
            {'label': 'Date', 'pattern': '先月'},
            {'label': 'Date', 'pattern': '今月'},
            {'label': 'Date', 'pattern': '来月'},
            {'label': 'Date', 'pattern': '昨年'},
            {'label': 'Date', 'pattern': '今年'},
            {'label': 'Date', 'pattern': '来年'},
            {'label': 'Date', 'pattern': '年前'}
        ]
        self._known_sessions: Dict[str, bool] = {}  # session_id -> True
        # モデルのロード
        self.nlp = spacy.load(self.block_config.get('model_name'))

        # Language specific processing
        if self.config.get('language') == 'ja':
            # Set the first system utterance in Japanese.
            self.first_system_utterance = "固有表現抽出のテストチャットです.入力に対してラベルを返します." \
                f"（model:{self.block_config.get('model_name')}）"
            # ルールの追加
            config = {'overwrite_ents': True}
            ruler = self.nlp.add_pipe('entity_ruler', config=config)
            ruler.add_patterns(self.patterns)
        else:
            # Set the first system utterance in English.
            self.first_system_utterance = "This is a test chat for Named Entity Recognition. " \
                f"Returns a label for the input.（model:{self.block_config.get('model_name')}）"

    def process(self, input: Dict[str, Any], session_id: str) -> Dict[str, Any]:
        """
        :param input. keys: "input_text", "input_aux_data"
        :return: output. keyss: "output_text", "output_aux_data"
        """

        self.log_debug("input: " + str(input))
        continuing_session: bool = self._known_sessions.get(session_id, False)
        if not continuing_session:
            self._known_sessions[session_id] = True
            system_utterance = self.first_system_utterance
            output = {"output_text": system_utterance, "output_aux_data": {}, "final": False, "session_id": session_id}
        else:
            # 固有表現抽出
            doc = self.nlp(input['input_text'])
            self.log_debug(f"text:{doc.text}")
            ner_result = {}

            # 単語とラベルを設定
            for ent in doc.ents:
                if ent.label_ in ner_result.keys():
                    # 複数ある場合は追加していく
                    ner_result[ent.label_].add(ent.text)
                else:
                    # 重複除外のためsetを使用
                    ner_result[ent.label_] = set([ent.text])
            # 複数パターンをコロンで連結
            for k, v in ner_result.items():
                ner_result[k] = (':').join(v)

            output = {"output_text": ner_result, "final": False, "session_id": session_id}
        self.log_debug("output: " + str(output))
        return output
