GiNZAによる固有表現抽出の導入
=================

仕様
-----------------
* GiNZAを使った固有表現抽出ブロックを実装する
* understanderの出力は対話制御で扱いやすい以下の形とする、  
  e.g. aux_data['person']='山田:鈴木'  
  ※同じクラスのが複数見つかった場合はコロンで連結
* ラベルはGiNZAの出力そのままを設定する、  
  e.g. 富士通=Company、鈴木=Person、金曜日=Day_Of_Week、…など
* "明日"などの相対日付が認識しないことが判明したので、今回はルールの追加で対応する

利用モデル
-----------------
* **ja_ginza_electra** ：BERTベースの日本語モデル
* **en_core_web_trf** ：spaCyの精度重視モデル

リリースファイル
-----------------
|ディレクトリ | ファイル | 内容 |
|---------|---------|------------|
|dialbb/builtin_blocks/understanding_with_ginza/ |ginza_understander.py|言語理解処理|
|./ |requirements.txt|ginzaインストール|
|sample_apps/network_ja|config_ginza.yml|日本語用Configファイル|
|sample_apps/network_en|config_ginza.yml|英語用Configファイル|

導入手順
-----------------
### [環境構築]  
1. 動作確認はPython3.8.10 で実施 
1. requiremenets.txtのライブラリをインストール  
1. モデルをインストール：  
  \$ python -m spacy download en_core_web_trf

### [実行方法]  
1. \$ cd dialbb-dev  
1.  ・日本語版：  
  \$ python run_server.py sample_apps/network_ja/config_ginza.yml  
  ・英語版：  
  \$ python run_server.py sample_apps/network_en/config_ginza.yml  

補足説明
-----------------
1. 現時点でアプリケーションが定まっていないためmanager処理は未実装、そのため言語理解結果をそのままresponseにしてチャット画面のsystem発話に表示させている
1. 固有表現ラベルはモデルに依存するのでファイル：ner_label_list.txt にまとめる

