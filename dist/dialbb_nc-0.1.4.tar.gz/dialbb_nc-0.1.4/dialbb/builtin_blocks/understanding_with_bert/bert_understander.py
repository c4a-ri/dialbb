#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# bert_understander.py
#   understand input text using BERT model

__version__ = '0.1'
__author__ = 'Mikio Nakano'
__copyright__ = 'C4A Research Institute, Inc.'

import json
import os
from typing import Any, Dict, Tuple

import fugashi
import numpy as np
import torch

from dialbb.abstract_block import AbstractBlock
from dialbb.builtin_blocks.understanding_with_bert.utils import (
    MODEL_CLASSES, get_device, get_intent_labels, get_slot_labels,
    load_tokenizer)
from dialbb.main import CONFIG_DIR, KEY_SESSION_ID
from dialbb.util.error_handlers import abort_during_building

KEY_INPUT_TEXT: str = "input_text"
KEY_NLU_RESULT: str = "nlu_result"


class Understander(AbstractBlock):
    """
    BERT based understander
    """

    def __init__(self, *args):

        super().__init__(*args)
        self.model_path = os.path.join(CONFIG_DIR, self.block_config.get('model_dir'))

        # read arguments of training model
        self.model_args = torch.load(os.path.join(self.model_path, 'training_args.bin'))
        self.log_debug(self.model_args)

        # load model
        self.device = get_device(self.model_args)
        self.log_debug('device:' + self.device)
        self.model = self.load_model()

        # load Tokenizer
        self.tokenizer = load_tokenizer(self.model_args)

        self.intent_label_lst = get_intent_labels(self.model_args)
        self.slot_label_lst = get_slot_labels(self.model_args)

        # set word segmentation
        self.wakati = fugashi.Tagger("-Owakati")

        # read synonyms list
        self.synonym_list = {}
        file_path = os.path.join(CONFIG_DIR, self.block_config.get('data_dir'),
                                 self.block_config.get('synonyms_list_file'))
        with open(file_path, 'r', encoding='utf-8') as f:
            self.synonym_list = json.load(f)

    def load_model(self):
        """
        load model from local
        """
        # Check whether model exists
        if not os.path.exists(self.model_path):
            raise Exception("Model doesn't exists! Train first!")

        try:
            model = MODEL_CLASSES[self.model_args.model_type][1]. \
                from_pretrained(self.model_path,
                                args=self.model_args,
                                intent_label_lst=get_intent_labels(self.model_args),
                                slot_label_lst=get_slot_labels(self.model_args))
            model.to(self.device)
            model.eval()
            self.log_info(f"** Model Loaded : type={self.model_args.model_type} path={self.model_path}")
        except Exception:
            abort_during_building(f"Some model files might be missing. path={self.model_path}")

        return model

    def convert_utterance_to_tensor_dataset(self, words,
                                            tokenizer,
                                            pad_token_label_id,
                                            cls_token_segment_id=0,
                                            pad_token_segment_id=0,
                                            sequence_a_segment_id=0,
                                            mask_padding_with_zero=True) -> Tuple[Any, Any, Any, Any]:
        """
        convert utterance to tensor dataset
        :param input utterance
        :param use tokenizer
        :param label ID of pad token
        :return: tensor dataset  e.g. (input ids, attention mask, token type, slot label)
        """
        # Setting based on the current model type
        cls_token = tokenizer.cls_token
        sep_token = tokenizer.sep_token
        unk_token = tokenizer.unk_token
        pad_token_id = tokenizer.pad_token_id

        all_input_ids = []
        all_attention_mask = []
        all_token_type_ids = []
        all_slot_label_mask = []

        tokens = []
        slot_label_mask = []
        for word in words:
            word_tokens = tokenizer.tokenize(word)
            if not word_tokens:
                word_tokens = [unk_token]  # For handling the bad-encoded word
            tokens.extend(word_tokens)
            # Use the real label id for the first token of the word, and padding ids for the remaining tokens
            slot_label_mask.extend([pad_token_label_id + 1] + [pad_token_label_id] * (len(word_tokens) - 1))

        # Account for [CLS] and [SEP]
        special_tokens_count = 2
        if len(tokens) > self.model_args.max_seq_len - special_tokens_count:
            tokens = tokens[: (self.model_args.max_seq_len - special_tokens_count)]
            slot_label_mask = slot_label_mask[:(self.model_args.max_seq_len - special_tokens_count)]

        # Add [SEP] token
        tokens += [sep_token]
        token_type_ids = [sequence_a_segment_id] * len(tokens)
        slot_label_mask += [pad_token_label_id]

        # Add [CLS] token
        tokens = [cls_token] + tokens
        token_type_ids = [cls_token_segment_id] + token_type_ids
        slot_label_mask = [pad_token_label_id] + slot_label_mask

        input_ids = tokenizer.convert_tokens_to_ids(tokens)

        # The mask has 1 for real tokens and 0 for padding tokens. Only real tokens are attended to.
        attention_mask = [1 if mask_padding_with_zero else 0] * len(input_ids)

        # Zero-pad up to the sequence length.
        padding_length = self.model_args.max_seq_len - len(input_ids)
        input_ids = input_ids + ([pad_token_id] * padding_length)
        attention_mask = attention_mask + ([0 if mask_padding_with_zero else 1] * padding_length)
        token_type_ids = token_type_ids + ([pad_token_segment_id] * padding_length)
        slot_label_mask = slot_label_mask + ([pad_token_label_id] * padding_length)

        all_input_ids.append(input_ids)
        all_attention_mask.append(attention_mask)
        all_token_type_ids.append(token_type_ids)
        all_slot_label_mask.append(slot_label_mask)

        # Change to Tensor
        all_input_ids = torch.tensor(all_input_ids, dtype=torch.long)
        all_attention_mask = torch.tensor(all_attention_mask, dtype=torch.long)
        all_token_type_ids = torch.tensor(all_token_type_ids, dtype=torch.long)
        all_slot_label_mask = torch.tensor(all_slot_label_mask, dtype=torch.long)

        # dataset = TensorDataset(all_input_ids, all_attention_mask, all_token_type_ids, all_slot_label_mask)
        dataset = (all_input_ids, all_attention_mask, all_token_type_ids, all_slot_label_mask)

        return dataset

    def process(self, input: Dict[str, Any], session_id: str) -> Dict[str, Any]:
        """
        understand input sentenc usig BERT
        :param e.g. {"sentence": "I love egg salad sandwiches"}
        :param initial: whether processing the first utterance of the session
        :return: e.g., {"nlu_result {"type": "tell_favorite_sandwiches", "slots": {"sandwich": "egg salad sandwich"}}}
        """

        session_id: str = input.get(KEY_SESSION_ID, "undecided")
        self.log_debug("input: " + str(input), session_id=session_id)
        slots: Dict[str, str] = {}
        intent = ""

        sentence: str = input[KEY_INPUT_TEXT]
        if sentence != "":

            # word segmentation
            words = self.wakati.parse(sentence).split()
            self.log_debug(words, session_id=session_id)

            # Convert input utterance to TensorDataset
            pad_token_label_id = self.model_args.ignore_index
            dataset = self.convert_utterance_to_tensor_dataset(words, self.tokenizer, pad_token_label_id)

            all_slot_label_mask = None
            intent_preds = None
            slot_preds = None

            batch = tuple(t.to(self.device) for t in dataset)
            with torch.no_grad():
                inputs = {"input_ids": batch[0],
                          "attention_mask": batch[1],
                          "intent_label_ids": None,
                          "slot_labels_ids": None}
                if self.model_args.model_type != "distilbert":
                    inputs["token_type_ids"] = batch[2]
                outputs = self.model(**inputs)
                _, (intent_logits, slot_logits) = outputs[:2]
                self.log_debug('intent_logits:{}'.format(intent_logits), session_id=session_id)
                self.log_debug('slot_logits:{}'.format(slot_logits), session_id=session_id)

                # Intent Prediction
                if intent_preds is None:
                    intent_preds = intent_logits.detach().cpu().numpy()
                else:
                    intent_preds = np.append(intent_preds, intent_logits.detach().cpu().numpy(), axis=0)

                # Slot prediction
                if slot_preds is None:
                    if self.model_args.use_crf:
                        # decode() in `torchcrf` returns list with best index directly
                        slot_preds = np.array(self.model.crf.decode(slot_logits))
                    else:
                        slot_preds = slot_logits.detach().cpu().numpy()
                    all_slot_label_mask = batch[3].detach().cpu().numpy()
                else:
                    if self.model_args.use_crf:
                        slot_preds = np.append(slot_preds, np.array(self.model.crf.decode(slot_logits)), axis=0)
                    else:
                        slot_preds = np.append(slot_preds, slot_logits.detach().cpu().numpy(), axis=0)
                    all_slot_label_mask = np.append(all_slot_label_mask, batch[3].detach().cpu().numpy(), axis=0)

            intent_preds = np.argmax(intent_preds, axis=1)

            if not self.model_args.use_crf:
                slot_preds = np.argmax(slot_preds, axis=2)

            slot_label_map = {i: label for i, label in enumerate(self.slot_label_lst)}
            slot_preds_list = [[] for _ in range(slot_preds.shape[0])]

            for i in range(slot_preds.shape[0]):
                for j in range(slot_preds.shape[1]):
                    if all_slot_label_mask[i, j] != pad_token_label_id:
                        slot_preds_list[i].append(slot_label_map[slot_preds[i][j]])

            self.log_debug('slot_preds_list:{}'.format(slot_preds_list), session_id=session_id)
            self.log_debug('intent_preds:{}'.format(intent_preds), session_id=session_id)

            # to output
            slot_preds = slot_preds_list[0]
            intent_pred = intent_preds[0]
            intent = self.intent_label_lst[intent_pred]

            self.log_debug(f"words={words}\n", session_id=session_id)
            self.log_debug(f"slot_preds={slot_preds}\n", session_id=session_id)

            vocab = ''
            pred = ''
            # add marker for last
            words.append('')
            slot_preds.append('O')
            for w, p in zip(words, slot_preds):
                if p.startswith('B-'):
                    if len(vocab) != 0:
                        slots[pred] = vocab
                        vocab = ''
                    vocab = w
                    pred = p.replace('B-', '')
                elif p.startswith('I-'):
                    vocab += w
                elif p == 'O' and len(vocab) != 0:
                    slots[pred] = vocab
                    vocab = ''

            # conver synonyms to entity
            for slot, value in slots.items():
                self.log_debug(f"slot check : {slot}", session_id=session_id)
                try:
                    slots[slot] = self.synonym_list[slot][value]
                    self.log_debug(f"conver synonyms : {value} => {slots[slot]}", session_id=session_id)
                except KeyError:
                    pass

        nlu_result = {"type": intent, "slots": slots}
        output = {KEY_NLU_RESULT: nlu_result}
        self.log_info("output: " + str(output), session_id=session_id)

        return output
