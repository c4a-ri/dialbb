#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# bert_model_creator.py
#   create BERT model from nlu knowledge file

__version__ = '0.1'
__author__ = 'Mikio Nakano'
__copyright__ = 'C4A Research Institute, Inc.'

import os
import sys
import argparse
import logging
from sklearn.model_selection import train_test_split
from dotmap import DotMap

DIALBB_HOME = os.getcwd()
sys.path.append(DIALBB_HOME)

from dialbb.builtin_blocks.understanding_with_bert.knowledge_converter import read_knowledge_data, \
    get_types, get_utterance, save_knowledge_data, vocab_process, createSynonyms
from dialbb.builtin_blocks.understanding_with_bert.data_loader import load_and_cache_examples
from dialbb.builtin_blocks.understanding_with_bert.utils import init_logger, load_tokenizer, set_seed, \
    MODEL_PATH_MAP, read_config
from dialbb.builtin_blocks.understanding_with_bert.trainer import Trainer

logger = logging.getLogger(__name__)


def convert_knowledge_data(conf: DotMap) -> None:
    """
    Creating Training Data from NLU Knowledge File
    :param configuration
    """

    # read knowledge description file
    knowledge_excel = os.path.join(conf.app_dir, conf.knowledge_file)
    df = read_knowledge_data(knowledge_excel)

    # get classification type
    type_labels = get_types(df)

    # get Tokenizer
    tokenizer = load_tokenizer(conf)

    # get sentence te and BIO label position
    texts_list, labels_list = get_utterance(df, tokenizer)

    # split data for cross Validation
    types = [[], [], []]
    texts = [[], [], []]
    labels = [[], [], []]
    # train:70%, valid:20%, test:10% 分割
    # トレーニング／検証／テストに分割
    # sample-knowledge-ja.xlsxのutterancesは43個なので
    # 30/10/3
    types[0], tmp_types, texts[0], tmp_texts, labels[0], tmp_labels = \
        train_test_split(type_labels, texts_list, labels_list, train_size=0.7)
    logger.info(f'train data size:{len(types[0])}')
    types[1], types[2], texts[1], texts[2], labels[1], labels[2] = \
        train_test_split(tmp_types, tmp_texts, tmp_labels, test_size=0.3)
    logger.info(f'dev data size:{len(types[1])}, test data size:{len(types[2])}')

    data_path = os.path.join(conf.app_dir, conf.data_dir)

    # output files to each folder
    for i, kind in enumerate(['train', 'dev', 'test']):
        save_knowledge_data(types[i], texts[i], labels[i], os.path.join(data_path, kind))

    # create a unique list
    # 分類タイプとスロットラベルのインデックスを保存
    vocab_process(conf.intent_label_file, conf.slot_label_file, data_path)

    # create a synonyms list and saved
    # 同義語リストをjsonで保存
    createSynonyms(df, conf.synonyms_list_file, data_path)


def train(conf: DotMap) -> None:
    """
    Training process
    :param configuration
    """
    # 乱数のシードを固定する、seed値はconfig_bert.ymlより (=1234)
    set_seed(conf)
    # トークナイザをロード、utilsのテーブルより (=BertJapaneseTokenizer)
    tokenizer = load_tokenizer(conf)

    # 事前に知識記述から変換したデータを[学習/検証/テスト]に分割
    train_dataset = load_and_cache_examples(conf, tokenizer, mode="train")
    dev_dataset = load_and_cache_examples(conf, tokenizer, mode="dev")
    test_dataset = load_and_cache_examples(conf, tokenizer, mode="test")

    # 
    trainer = Trainer(conf, train_dataset, dev_dataset, test_dataset)

    if conf.do_train:
        trainer.train()

    if conf.do_eval:
        trainer.load_model()
        trainer.evaluate("test")

# コマンドラインからの起動処理
# python dialbb/builtin_blocks/understanding_with_bert/bert_model_creator.py sample_apps/network_ja/bert_training_param.yml
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("config", help="config yaml file")
    args = parser.parse_args()

    config_file: str = args.config

    # read config file
    # bert_training_param.ymlを読み込む
    config = read_config(config_file)
    if len(config):
        init_logger(config.log_level)

        # set application directory
        config.app_dir = os.path.dirname(config_file)

        # set name of pretraining BERT model
        # 事前学習モデルは'cl-tohoku/bert-base-japanese-whole-word-masking'
        # （utilsのテーブルよりセット）
        config.base_model_name = MODEL_PATH_MAP[config.model_type]
        logger.info(f'config.base_model_name:{config.base_model_name}')
        # logger.info(config)

        # read knowledge data
        # 知識記述ファイルより学習データを読み込む
        convert_knowledge_data(config)

        # start fine-tuning
        # ファインチューニングの開始
        train(config)
