#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# trainer.py
#   Fine-tuning the BERT model

__version__ = '0.1'
__author__ = 'Mikio Nakano'
__copyright__ = 'C4A Research Institute, Inc.'

import os
import logging
from tqdm import tqdm, trange

import numpy as np
import torch
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler
from transformers import AdamW, get_linear_schedule_with_warmup

from dialbb.builtin_blocks.understanding_with_bert.utils import MODEL_CLASSES, compute_metrics, \
    get_device, get_intent_labels, get_slot_labels

logger = logging.getLogger(__name__)


class Trainer(object):
    def __init__(self, args, train_dataset=None, dev_dataset=None, test_dataset=None):
        self.args = args
        self.train_dataset = train_dataset
        self.dev_dataset = dev_dataset
        self.test_dataset = test_dataset

        # 分類タイプとスロットラベルのインデックスを読み込み
        self.intent_label_lst = get_intent_labels(args)
        self.slot_label_lst = get_slot_labels(args)
        # Use cross entropy ignore index as padding label id so that only real
        #  label ids contribute to the loss later.
        self.pad_token_label_id = args.ignore_index

        # 今回はbertなので、config_class="BertConfig", model_class="JointBERT"
        self.config_class, self.model_class, _ = MODEL_CLASSES[args.model_type]
        # 使用するBERTのモデル='cl-tohoku/bert-base-japanese-whole-word-masking'
        # BERTのConfigをロード
        self.config = self.config_class.from_pretrained(args.base_model_name,
                                                        finetuning_task=args.task)
        # BERTの事前学習モデルをロード
        # モデルのクラス='JointBERT'
        self.model = self.model_class.from_pretrained(args.base_model_name,
                                                      config=self.config,
                                                      args=args,
                                                      intent_label_lst=self.intent_label_lst,
                                                      slot_label_lst=self.slot_label_lst)

        # GPU or CPU
        self.device = get_device(args)
        self.model.to(self.device)
        logger.info("  model_type = %s", args.model_type)
        logger.info("  base_model_name = %s", args.base_model_name)

    def train(self):
        """
        Execute training
        :return global step and loss
        """
        # DataLoaderのセット、訓練データはランダムに抽出
        train_sampler = RandomSampler(self.train_dataset)
        train_dataloader = DataLoader(self.train_dataset, sampler=train_sampler,
                                      batch_size=self.args.train_batch_size)

        # 実行するトレーニングステップの計算
        if self.args.max_steps > 0:
            t_total = self.args.max_steps
            self.args.num_train_epochs = self.args.max_steps // \
                (len(train_dataloader) // self.args.gradient_accumulation_steps) + 1
        else:
            t_total = len(train_dataloader) // self.args.gradient_accumulation_steps \
                * self.args.num_train_epochs

        # Prepare optimizer and schedule (linear warmup and decay)
        # レイヤーの重みとバイアスを設定？ 詳細は不明
        no_decay = ['bias', 'LayerNorm.weight']
        optimizer_grouped_parameters = [
            {'params': [p for n, p in self.model.named_parameters() if not any(nd in n for nd in no_decay)],
                'weight_decay': self.args.weight_decay},
            {'params': [p for n, p in self.model.named_parameters() if any(nd in n for nd in no_decay)],
                'weight_decay': 0.0}
        ]
        # 最適化アルゴリズムは「Adam」を指定
        optimizer = AdamW(optimizer_grouped_parameters, lr=float(self.args.learning_rate),
                          eps=float(self.args.adam_epsilon))
        # スケジューラは？
        scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=self.args.warmup_steps,
                                                    num_training_steps=t_total)

        # Train!
        logger.debug("***** Running training *****")
        logger.debug("  Num examples = %d", len(self.train_dataset))
        logger.debug("  Num Epochs = %d", self.args.num_train_epochs)
        logger.debug("  Total train batch size = %d", self.args.train_batch_size)
        logger.debug("  Gradient Accumulation steps = %d", self.args.gradient_accumulation_steps)
        logger.debug("  Total optimization steps = %d", t_total)
        logger.debug("  Logging steps = %d", self.args.logging_steps)
        logger.debug("  Save steps = %d", self.args.save_steps)

        global_step = 0
        tr_loss = 0.0
        # 勾配をゼロで初期化
        self.model.zero_grad()
        saved_flag = False

        # プログレスバー表示（Epoch用）
        train_iterator = trange(int(self.args.num_train_epochs), desc="Epoch")

        for _ in train_iterator:
            # ミニバッチループ（プログレスバー表示も含む）
            epoch_iterator = tqdm(train_dataloader, desc="Iteration")
            for step, batch in enumerate(epoch_iterator):
                # 訓練モードに設定
                self.model.train()
                # デバイスの指定
                batch = tuple(t.to(self.device) for t in batch)  # GPU or CPU

                # 訓練データを入力パラメータにセット
                inputs = {'input_ids': batch[0],
                          'attention_mask': batch[1],
                          'intent_label_ids': batch[3],
                          'slot_labels_ids': batch[4]}
                if self.args.model_type != 'distilbert':
                    inputs['token_type_ids'] = batch[2]
                # 学習データをモデルにかける
                outputs = self.model(**inputs)
                # 今回はモデル側で損失関数をかけているのでそのままlossに代入
                # 配列先頭はタイプ分類とスロット抽出の合計ロス値
                loss = outputs[0]

                # 現状のconfigは"1"なのでこの処理はスキップ
                if self.args.gradient_accumulation_steps > 1:
                    loss = loss / self.args.gradient_accumulation_steps

                # バックプロパゲーションを実行.  ※勾配を計算（自動微分）を含む
                loss.backward()

                tr_loss += loss.item()
                if (step + 1) % self.args.gradient_accumulation_steps == 0:
                    # 勾配爆発を抑制するための対策(らしい)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.args.max_grad_norm)

                    # パラメータを更新する
                    optimizer.step()
                    scheduler.step()  # Update learning rate schedule
                    # 更新したら勾配はリセット
                    self.model.zero_grad()
                    global_step += 1

                    # logging_steps(=20)に1回「検証」する
                    if self.args.logging_steps > 0 and global_step % self.args.logging_steps == 0:
                        # 検証の実行
                        self.evaluate("dev")

                    if self.args.save_steps > 0 and global_step % self.args.save_steps == 0:
                        # save model
                        # チェックポイントの保存
                        self.save_model()
                        saved_flag = True

                if 0 < self.args.max_steps < global_step:
                    epoch_iterator.close()
                    break

            if 0 < self.args.max_steps < global_step:
                train_iterator.close()
                break

        if not saved_flag:
            # save model
            self.save_model()

        return global_step, tr_loss / global_step

    def evaluate(self, mode):
        """
        Execute evaluating
        :param mode of evaluate [dev/test]
        :return loss
        """
        if mode == 'test':
            dataset = self.test_dataset
        elif mode == 'dev':
            dataset = self.dev_dataset
        else:
            raise Exception("Only dev and test dataset available")

        # DataLoaderのセット、データはシーケンシャルに抽出
        eval_sampler = SequentialSampler(dataset)
        eval_dataloader = DataLoader(dataset, sampler=eval_sampler, batch_size=self.args.eval_batch_size)

        # Eval!
        logger.info("***** Running evaluation on %s dataset *****", mode)
        logger.info("  Num examples = %d", len(dataset))
        logger.info("  Batch size = %d", self.args.eval_batch_size)
        eval_loss = 0.0
        nb_eval_steps = 0
        intent_preds = None
        slot_preds = None
        out_intent_label_ids = None
        out_slot_labels_ids = None

        # 推論モード
        self.model.eval()

        for batch in tqdm(eval_dataloader, desc="Evaluating"):
            batch = tuple(t.to(self.device) for t in batch)
            # 推論のため勾配の計算をしない
            with torch.no_grad():
                inputs = {'input_ids': batch[0],
                          'attention_mask': batch[1],
                          'intent_label_ids': batch[3],
                          'slot_labels_ids': batch[4]}
                if self.args.model_type != 'distilbert':
                    inputs['token_type_ids'] = batch[2]
                # 推論
                outputs = self.model(**inputs)
                tmp_eval_loss, (intent_logits, slot_logits) = outputs[:2]

                eval_loss += tmp_eval_loss.mean().item()
            nb_eval_steps += 1

            # Intent prediction
            if intent_preds is None:
                intent_preds = intent_logits.detach().cpu().numpy()
                out_intent_label_ids = inputs['intent_label_ids'].detach().cpu().numpy()
            else:
                intent_preds = np.append(intent_preds, intent_logits.detach().cpu().numpy(), axis=0)
                out_intent_label_ids = np.append(
                    out_intent_label_ids, inputs['intent_label_ids'].detach().cpu().numpy(), axis=0)

            # Slot prediction
            if slot_preds is None:
                if self.args.use_crf:
                    # decode() in `torchcrf` returns list with best index directly
                    slot_preds = np.array(self.model.crf.decode(slot_logits))
                else:
                    slot_preds = slot_logits.detach().cpu().numpy()

                out_slot_labels_ids = inputs["slot_labels_ids"].detach().cpu().numpy()
            else:
                if self.args.use_crf:
                    slot_preds = np.append(slot_preds, np.array(self.model.crf.decode(slot_logits)), axis=0)
                else:
                    slot_preds = np.append(slot_preds, slot_logits.detach().cpu().numpy(), axis=0)

                out_slot_labels_ids = np.append(out_slot_labels_ids, inputs["slot_labels_ids"].detach().cpu().numpy(),
                                                axis=0)

        eval_loss = eval_loss / nb_eval_steps
        results = {
            "loss": eval_loss
        }

        # Intent result
        intent_preds = np.argmax(intent_preds, axis=1)

        # Slot result
        if not self.args.use_crf:
            slot_preds = np.argmax(slot_preds, axis=2)
        slot_label_map = {i: label for i, label in enumerate(self.slot_label_lst)}
        out_slot_label_list = [[] for _ in range(out_slot_labels_ids.shape[0])]
        slot_preds_list = [[] for _ in range(out_slot_labels_ids.shape[0])]

        for i in range(out_slot_labels_ids.shape[0]):
            for j in range(out_slot_labels_ids.shape[1]):
                if out_slot_labels_ids[i, j] != self.pad_token_label_id:
                    out_slot_label_list[i].append(slot_label_map[out_slot_labels_ids[i][j]])
                    slot_preds_list[i].append(slot_label_map[slot_preds[i][j]])

        total_result = compute_metrics(intent_preds, out_intent_label_ids, slot_preds_list, out_slot_label_list)
        results.update(total_result)

        logger.info(f"***** Eval results mode={mode} *****")
        for key in sorted(results.keys()):
            logger.info("  %s = %s", key, str(results[key]))

        return results

    def save_model(self):
        """
        Save model checkpoint (Overwrite)
        """
        model_dir = os.path.join(self.args.app_dir, self.args.model_dir)
        if not os.path.exists(model_dir):
            os.makedirs(model_dir)
        model_to_save = self.model.module if hasattr(self.model, 'module') else self.model
        model_to_save.save_pretrained(model_dir)

        # Save training arguments together with the trained model
        torch.save(self.args, os.path.join(model_dir, 'training_args.bin'))
        logger.info("Saving model checkpoint to %s", model_dir)

    def load_model(self):
        """
        Load model from model directory
        """
        model_dir = os.path.join(self.args.app_dir, self.args.model_dir)
        model_path = ''
        # Check whether model exists
        if not os.path.exists(model_dir):
            # raise Exception("Model doesn't exists! Train first!")
            model_path = self.args.model_name_or_path
        else:
            model_path = model_dir

        try:
            self.model = self.model_class.from_pretrained(model_path,
                                                          args=self.args,
                                                          intent_label_lst=self.intent_label_lst,
                                                          slot_label_lst=self.slot_label_lst)
            self.model.to(self.device)
            logger.info("***** Model Loaded *****")
        except Exception:
            raise Exception("Some model files might be missing...")
