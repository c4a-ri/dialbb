import torch.nn as nn


# ニューラルネットワークのクラス定義：発話タイプの分類用
class IntentClassifier(nn.Module):
    # 層（layer：レイヤー）を定義
    def __init__(self, input_dim, num_intent_labels, dropout_rate=0.):
        super(IntentClassifier, self).__init__()
        
        # ドロップアウトを適用（レート=0.1)
        self.dropout = nn.Dropout(dropout_rate)
        # 全結合層、入力サイズ=BERTのConfigより（=768）、
        #   出力サイズ=知識記述よりスロットラベルの数
        self.linear = nn.Linear(input_dim, num_intent_labels)

    # フォワードプロパゲーション（順伝播）
    def forward(self, x):
        x = self.dropout(x)     # ドロップアウトさせて
        return self.linear(x)   # 線形変換結果を出力


# ニューラルネットワークのクラス定義：スロット抽出用
class SlotClassifier(nn.Module):
    def __init__(self, input_dim, num_slot_labels, dropout_rate=0.):
        super(SlotClassifier, self).__init__()
        self.dropout = nn.Dropout(dropout_rate)
        self.linear = nn.Linear(input_dim, num_slot_labels)

    def forward(self, x):
        x = self.dropout(x)
        return self.linear(x)
