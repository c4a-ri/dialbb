import io
from queue import Empty, Queue
from threading import Event

import pygame
from google.api_core.exceptions import GoogleAPICallError, RetryError
from google.cloud import texttospeech

from dialbb.util.logger import get_logger
from ..main.messages import TtsRequest, TtsResult


logger = get_logger(__name__)

# Google Cloud TTS の音声設定。
_LANGUAGE_CODE = "ja-JP"
_VOICE_NAME = "ja-JP-Neural2-B"
_AUDIO_ENCODING = texttospeech.AudioEncoding.MP3


def _ensure_mixer_initialized() -> bool:
    """pygame mixer を必要時に初期化する。"""
    if pygame.mixer.get_init() is not None:
        return True
    try:
        pygame.mixer.init()
    except pygame.error:
        logger.exception("[TTS] pygame mixer 初期化に失敗")
        return False
    return True


def _synthesize_with_encoding(
    client: texttospeech.TextToSpeechClient,
    text: str,
    audio_encoding: texttospeech.AudioEncoding,
) -> bytes:
    """指定したエンコーディングで Google Cloud TTS 合成を行う。"""
    synthesis_input = texttospeech.SynthesisInput(text=text)
    voice = texttospeech.VoiceSelectionParams(
        language_code=_LANGUAGE_CODE,
        name=_VOICE_NAME,
    )
    audio_config = texttospeech.AudioConfig(audio_encoding=audio_encoding)
    response = client.synthesize_speech(
        input=synthesis_input,
        voice=voice,
        audio_config=audio_config,
    )
    return response.audio_content


def _synthesize(client: texttospeech.TextToSpeechClient, text: str) -> bytes:
    """テキストを Google Cloud TTS で合成して既定形式のバイト列を返す。"""
    return _synthesize_with_encoding(client, text, _AUDIO_ENCODING)


def _play_audio(
    audio_bytes: bytes,
    stop_event: Event,
    conversation_active_event: Event,
    cancel_queue: "Queue | None" = None,
    audio_format: str = "mp3",
) -> bool:
    """音声バイト列を pygame で再生する。

    Returns:
        True: 最後まで再生完了。
        False: stop_event / conversation_active_event / cancel_queue により中断。
    """
    if not _ensure_mixer_initialized():
        return False

    buf = io.BytesIO(audio_bytes)
    try:
        pygame.mixer.music.load(buf, audio_format)
        pygame.mixer.music.play()
    except pygame.error:
        logger.exception("[TTS] 音声再生の開始に失敗(format=%s)", audio_format)
        return False
    while pygame.mixer.music.get_busy():
        if stop_event.is_set() or not conversation_active_event.is_set():
            pygame.mixer.music.stop()
            return False
        if cancel_queue is not None:
            try:
                cancel_queue.get_nowait()
                logger.debug("[TTS] キャンセルキュー受信: 再生中断")
                pygame.mixer.music.stop()
                return False
            except Empty:
                pass
        pygame.time.wait(50)
    return True


def run_tts_worker(
    tts_request_queue: "Queue[TtsRequest]",
    tts_result_queue: "Queue[TtsResult]",
    stop_event: Event,
    conversation_active_event: "Event | None" = None,
    tts_cancel_queue: "Queue | None" = None,
) -> None:
    """Google Cloud TTS + pygame による音声合成・再生ワーカースレッド。

    テキストを句点「。」で分割して逐次合成・再生し、
    stop_event / conversation_active_event / tts_cancel_queue で再生を中断できる。
    """
    client = texttospeech.TextToSpeechClient()
    # conversation_active_event が渡されない場合は常に active とみなす。
    active_event = conversation_active_event or Event()
    if conversation_active_event is None:
        active_event.set()

    # ワーカースレッド開始時にミキサ初期化を試みる（失敗してもワーカーは継続）。
    mixer_available = _ensure_mixer_initialized()
    if not mixer_available:
        logger.error("[TTS] 音声出力初期化に失敗。再生要求時に再試行します。")

    while not stop_event.is_set():
        try:
            request = tts_request_queue.get(timeout=0.1)
        except Empty:
            continue

        logger.info("[TTS] TTS<-MAIN 合成要求受信")
        logger.debug("[TTS] request.text=%s", request.text)

        # 前回リクエストの残留キャンセル信号を捨てる（stale cancel 対策）。
        if tts_cancel_queue is not None:
            while not tts_cancel_queue.empty():
                try:
                    tts_cancel_queue.get_nowait()
                except Empty:
                    break

        # 句点で分割し、空セグメントを除去する。
        segments = [s.strip() for s in request.text.split("。") if s.strip()]
        # 末尾が「。」で終わっていた場合は再度「。」を付け直す。
        segments = [
            (seg + "。") if not seg.endswith(("。", "！", "？", "!", "?")) else seg
            for seg in segments
        ]

        completed = True
        for segment in segments:
            if stop_event.is_set() or not active_event.is_set():
                logger.debug("[TTS] 中断: %s", segment)
                completed = False
                break

            # セグメント処理開始前にキャンセル信号を確認する。
            if tts_cancel_queue is not None and not tts_cancel_queue.empty():
                try:
                    tts_cancel_queue.get_nowait()
                    logger.debug("[TTS] セグメント開始前にキャンセル検知: 再生中断")
                except Empty:
                    pass
                completed = False
                break

            logger.debug("[TTS] 合成中: %s", segment)
            try:
                audio_bytes = _synthesize(client, segment)
            except (GoogleAPICallError, RetryError, OSError):
                logger.exception("[TTS] 合成エラー: %s", segment)
                completed = False
                break

            finished = _play_audio(
                audio_bytes,
                stop_event,
                active_event,
                tts_cancel_queue,
                audio_format="mp3",
            )
            if not finished:
                # MP3 デコード不可環境向けに LINEAR16(WAV) で再合成して再生を試みる。
                logger.warning("[TTS] MP3再生失敗。LINEAR16(WAV)へフォールバックします。")
                try:
                    wav_audio = _synthesize_with_encoding(
                        client,
                        segment,
                        texttospeech.AudioEncoding.LINEAR16,
                    )
                except (GoogleAPICallError, RetryError, OSError):
                    logger.exception("[TTS] WAVフォールバック合成エラー: %s", segment)
                    completed = False
                    break

                finished = _play_audio(
                    wav_audio,
                    stop_event,
                    active_event,
                    tts_cancel_queue,
                    audio_format="wav",
                )
            if not finished:
                logger.debug("[TTS] 再生中断: %s", segment)
                completed = False
                break

        tts_result_queue.put(
            TtsResult(
                session_id=request.session_id,
                text=request.text,
                completed=completed,
            )
        )
        logger.info("[TTS] TTS->MAIN 結果送信")
        if completed:
            logger.debug("[TTS] 合成・再生完了: %s", request.text)
