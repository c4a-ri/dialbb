# gui_launcher.py
# Cross-platform (Windows/macOS/Linux) Tkinter launcher for your PySide6 editor.
#
# START: launches editor as a separate process (stable; Qt should not run in a background thread)
# STOP : requests termination, then forces kill if needed
#
# Fixes:
# - Prevents the empty "tk" window (no implicit default root before Tk() is created)
# - Applies platform-safe ttk themes
# - Uses platform-friendly fonts
#
# Usage:
#   python gui_launcher.py
#
# Place this file next to your editor script (default: pyside_state_graph.py),
# or adjust EDITOR_SCRIPT path below.

from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path


# ---- Change this to your editor script filename/path ----
EDITOR_SCRIPT = "scenario_editor.py"
# Optional editor args:
EDITOR_ARGS: list[str] = []


def platform() -> str:
    if sys.platform.startswith("win"):
        return "win"
    if sys.platform == "darwin":
        return "mac"
    return "linux"


def apply_platform_style(root: tk.Tk) -> None:
    """
    Apply a safe ttk theme per OS.
    Must be called AFTER root (Tk) is created to avoid implicit default root ("tk" window).
    """
    style = ttk.Style(root)
    names = set(style.theme_names())
    p = platform()

    # Windows: "vista" looks most native when available
    if p == "win":
        if "vista" in names:
            style.theme_use("vista")
        elif "xpnative" in names:
            style.theme_use("xpnative")
        # else: keep default

    # macOS: default theme is already native-ish; don't force unless needed
    elif p == "mac":
        # Usually best to leave default
        # If you want to force something only when available, do it here.
        pass

    # Linux: "clam" is widely available and consistent
    else:
        if "clam" in names:
            style.theme_use("clam")


def title_font() -> tuple:
    """
    Platform-friendly title font.
    ttk may ignore some fonts depending on theme, but this is harmless.
    """
    p = platform()
    if p == "win":
        return ("Segoe UI", 13, "bold")
    if p == "mac":
        return ("Helvetica", 13, "bold")
    return ("Sans", 13, "bold")


class LauncherApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Scenario Editor Launcher")
        self.geometry("520x220")
        self.resizable(False, False)

        self.proc: subprocess.Popen | None = None
        self._watcher_stop = threading.Event()

        self._build_ui()
        self._update_ui_state()

        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_ui(self):
        pad = 12
        root = ttk.Frame(self, padding=pad)
        root.pack(fill="both", expand=True)

        title = ttk.Label(root, text="状態遷移エディタ 起動", font=title_font())
        title.pack(anchor="w")

        self.status_var = tk.StringVar(value="停止中")
        status = ttk.Label(root, textvariable=self.status_var)
        status.pack(anchor="w", pady=(6, 0))

        # Script path display
        self.script_var = tk.StringVar(value=str(self._resolved_editor_path()))
        script_row = ttk.Frame(root)
        script_row.pack(fill="x", pady=(10, 0))
        ttk.Label(script_row, text="Editor:").pack(side="left")
        ttk.Entry(script_row, textvariable=self.script_var, state="readonly").pack(
            side="left", fill="x", expand=True, padx=(8, 0)
        )

        # Buttons
        btn_row = ttk.Frame(root)
        btn_row.pack(fill="x", pady=(16, 0))

        self.btn_start = ttk.Button(btn_row, text="START", command=self.start_editor)
        self.btn_start.pack(side="left", padx=(0, 8))

        self.btn_stop = ttk.Button(btn_row, text="STOP", command=self.stop_editor)
        self.btn_stop.pack(side="left")

        self.btn_ping = ttk.Button(btn_row, text="状態確認", command=self.refresh_status)
        self.btn_ping.pack(side="right")

        hint = ttk.Label(
            root,
            text="※ STOP は terminate→(必要なら)kill で終了します。",
            foreground="#555",
        )
        hint.pack(anchor="w", pady=(14, 0))

    def _resolved_editor_path(self) -> Path:
        script_path = Path(EDITOR_SCRIPT)
        if not script_path.is_absolute():
            base = Path(__file__).resolve().parent
            script_path = (base / script_path).resolve()
        return script_path

    def _editor_cmd(self) -> list[str]:
        script_path = self._resolved_editor_path()
        if not script_path.exists():
            raise FileNotFoundError(f"Editor script not found: {script_path}")
        # Use the same Python interpreter that runs this launcher (important on macOS too)
        return [sys.executable, str(script_path), *EDITOR_ARGS]

    def start_editor(self):
        if self.proc and self.proc.poll() is None:
            messagebox.showinfo("Info", "すでに起動しています。")
            return

        try:
            cmd = self._editor_cmd()
        except Exception as e:
            messagebox.showerror("Error", f"起動できません: {e}")
            return

        try:
            creationflags = 0
            if platform() == "win":
                # type: ignore[attr-defined]
                creationflags = subprocess.CREATE_NEW_PROCESS_GROUP

            self.proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                cwd=str(Path(cmd[1]).resolve().parent),
                creationflags=creationflags,
            )
        except Exception as e:
            self.proc = None
            messagebox.showerror("Error", f"起動失敗: {e}")
            return

        self.status_var.set(f"起動中 (PID: {self.proc.pid})")
        self._update_ui_state()

        # Watcher thread: update UI when the process exits
        self._watcher_stop.clear()
        threading.Thread(target=self._watch_process_exit, daemon=True).start()

    def _watch_process_exit(self):
        while not self._watcher_stop.is_set():
            p = self.proc
            if not p:
                return
            code = p.poll()
            if code is not None:
                self.proc = None
                self._watcher_stop.set()
                self.after(0, self._on_editor_exited, code)
                return
            time.sleep(0.3)

    def _on_editor_exited(self, code: int):
        self.status_var.set(f"停止中（終了コード: {code}）")
        self._update_ui_state()

    def stop_editor(self):
        p = self.proc
        if not p or p.poll() is not None:
            self.proc = None
            self.status_var.set("停止中")
            self._update_ui_state()
            return

        # 1) request termination
        try:
            p.terminate()
        except Exception:
            pass

        # 2) wait a bit
        for _ in range(15):
            if p.poll() is not None:
                break
            self.update_idletasks()
            time.sleep(0.2)

        # 3) force kill if still alive
        if p.poll() is None:
            try:
                p.kill()
            except Exception:
                pass

        self.proc = None
        self._watcher_stop.set()
        self.status_var.set("停止中")
        self._update_ui_state()

    def refresh_status(self):
        if self.proc and self.proc.poll() is None:
            self.status_var.set(f"起動中 (PID: {self.proc.pid})")
        else:
            self.proc = None
            self.status_var.set("停止中")
        self._update_ui_state()

    def _update_ui_state(self):
        running = self.proc is not None and self.proc.poll() is None
        self.btn_start.configure(state=("disabled" if running else "normal"))
        self.btn_stop.configure(state=("normal" if running else "disabled"))

    def on_close(self):
        if self.proc and self.proc.poll() is None:
            if messagebox.askyesno("確認", "エディタも終了してから閉じますか？"):
                self.stop_editor()
        self._watcher_stop.set()
        self.destroy()


def main():
    # IMPORTANT: Create Tk root first (prevents empty "tk" window)
    app = LauncherApp()

    # Then apply ttk theme (platform safe)
    try:
        apply_platform_style(app)
    except (tk.TclError, AttributeError):
        pass

    app.mainloop()


if __name__ == "__main__":
    main()
