# scenario_converter2json.py
# scenario.xlsx -> state_graph.json converter
#
# Initial positions are assigned using the same idea as your editor's auto_layout:
#  - Build adjacency
#  - Find roots (System with incoming==0)
#  - BFS to assign levels
#  - Place each level at x = level * LAYOUT_DX
#  - Within each level, stack nodes vertically with spacing LAYOUT_DY
#    - If a level is all User nodes: sort by priority DESC (large first => upper)
#    - Otherwise: keep stable order (current y / creation order fallback)

from __future__ import annotations

import argparse
import json
import random
import string
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from collections import deque

from openpyxl import load_workbook


NODE_TYPE_SYSTEM = "system"
NODE_TYPE_USER = "user"

REQUIRED_HEADERS = [
    "state",
    "system utterance",
    "user utterance example",
    "user utterance type",
    "conditions",
    "actions",
    "next state",
]

# === Layout params (match your editor defaults) ===
LAYOUT_DX = 280.0  # NODE_W*2 when NODE_W=140
LAYOUT_DY = 310.0  # NODE_H_USER(260)+50


def generate_short_id(length: int = 6) -> str:
    chars = string.ascii_uppercase + string.digits
    return "".join(random.choices(chars, k=length))


def norm(s: Optional[str]) -> str:
    return (s or "").strip()


@dataclass
class NodeRec:
    id: str
    short_id: str
    x: float
    y: float
    text: str
    type: str
    fields: Dict[str, Any]


@dataclass(frozen=True)
class EdgeRec:
    from_id: str
    to_id: str
    from_conn: str = "right"
    to_conn: str = "left"


def build_header_index(header_row: List[object]) -> Dict[str, int]:
    idx: Dict[str, int] = {}
    for i, v in enumerate(header_row):
        name = norm(str(v) if v is not None else "")
        if name:
            idx[name] = i
    return idx


def cell_str(row: Tuple[object, ...], i: int) -> str:
    if i < 0 or i >= len(row):
        return ""
    v = row[i]
    return norm(str(v) if v is not None else "")


def user_priority_value(node: NodeRec) -> int:
    try:
        return int(str(node.fields.get("priority", "0") or "0"))
    except ValueError:
        return 0


def auto_layout_positions(nodes: Dict[str, NodeRec], edges: List[EdgeRec]) -> None:
    """
    Your editor-like auto layout:
      - adjacency is UNDIRECTED (for BFS reachability)
      - incoming_count is DIRECTED (for roots)
      - root: system nodes with incoming==0 (fallback: any incoming==0, fallback: all)
      - BFS from roots assigns levels
      - Unreached nodes get new levels appended to the right
      - For each level: x fixed by level, y stacked by LAYOUT_DY
        - If level is all users: priority DESC (large first => upper)
        - Else: preserve existing y order (or creation-ish)
    """

    if not nodes:
        return

    # --- 1) build undirected adjacency + incoming counts ---
    adj: Dict[str, set[str]] = {nid: set() for nid in nodes.keys()}
    incoming_count: Dict[str, int] = {nid: 0 for nid in nodes.keys()}

    for e in edges:
        a, b = e.from_id, e.to_id
        if a in adj and b in adj:
            adj[a].add(b)
            adj[b].add(a)
        if b in incoming_count:
            incoming_count[b] += 1
        incoming_count.setdefault(a, incoming_count.get(a, 0))

    # --- 2) roots ---
    roots = [
        nid for nid, n in nodes.items()
        if n.type == NODE_TYPE_SYSTEM and incoming_count.get(nid, 0) == 0
    ]
    if not roots:
        roots = [nid for nid in nodes.keys() if incoming_count.get(nid, 0) == 0]
    if not roots:
        roots = list(nodes.keys())

    # --- 3) BFS levels ---
    level: Dict[str, int] = {}
    q = deque()
    for r in roots:
        if r not in level:
            level[r] = 0
            q.append(r)

    while q:
        cur = q.popleft()
        cur_lv = level[cur]
        for nb in adj.get(cur, []):
            if nb not in level:
                level[nb] = cur_lv + 1
                q.append(nb)

    # Unreached nodes => put to the right
    if len(level) < len(nodes):
        max_lv = max(level.values()) if level else 0
        for nid in nodes.keys():
            if nid not in level:
                max_lv += 1
                level[nid] = max_lv

    # --- 4) group by level ---
    levels: Dict[int, List[str]] = {}
    for nid, lv in level.items():
        levels.setdefault(lv, []).append(nid)

    # --- 5) place ---
    base_x = 0.0
    base_y = 0.0

    for lv in sorted(levels.keys()):
        nids = levels[lv]
        x = base_x + lv * LAYOUT_DX

        # if all users => priority DESC
        if all(nodes[nid].type == NODE_TYPE_USER for nid in nids):
            nids_sorted = sorted(nids, key=lambda nid: user_priority_value(nodes[nid]), reverse=True)
        else:
            # keep current y as stable ordering if any
            nids_sorted = sorted(nids, key=lambda nid: float(nodes[nid].y))

        n = len(nids_sorted)
        start_y = base_y - (n - 1) * LAYOUT_DY / 2.0

        for i, nid in enumerate(nids_sorted):
            nodes[nid].x = x
            nodes[nid].y = start_y + i * LAYOUT_DY


def make_state_graph_from_xlsx(xlsx_path: Path) -> Dict[str, Any]:
    wb = load_workbook(xlsx_path, data_only=True)
    ws = wb["scenario"] if "scenario" in wb.sheetnames else wb.active

    rows_iter = ws.iter_rows(values_only=True)
    try:
        header = list(next(rows_iter))
    except StopIteration:
        raise ValueError("Excelが空です（ヘッダー行がありません）")

    hidx = build_header_index(header)
    missing = [h for h in REQUIRED_HEADERS if h not in hidx]
    if missing:
        raise ValueError(
            f"必要なヘッダーが見つかりません: {missing}\n見つかったヘッダー: {list(hidx.keys())}"
        )

    data_rows: List[Tuple[object, ...]] = []
    for r in rows_iter:
        # skip entirely empty rows (openpyxl may yield empty tuples for trailing blank rows)
        if not r or all((c is None or str(c).strip() == "") for c in r):
            continue

        state = cell_str(r, hidx["state"])
        sys_utt = cell_str(r, hidx["system utterance"])
        user_utt = cell_str(r, hidx["user utterance example"])
        user_type = cell_str(r, hidx["user utterance type"])
        cond = cell_str(r, hidx["conditions"])
        actions = cell_str(r, hidx["actions"])
        next_state = cell_str(r, hidx["next state"])

        print(f"Row: state='{state}', sys_utt='{sys_utt}', user_utt='{user_utt}', user_type='{user_type}', cond='{cond}', actions='{actions}', next_state='{next_state}'")
        if not (state or next_state or user_type or cond or sys_utt):
            print("###>Invalid row, node is not created.")
            continue
        # keep the row even if user-related cells are empty; later we'll
        # decide whether to create a user node or only system nodes/edges.
        if (user_utt + user_type + cond + actions + next_state) == "":
            print("###>user node is not created (system-only row).")
        data_rows.append(r)

    # registries
    system_by_kind: Dict[str, NodeRec] = {}
    user_nodes: List[NodeRec] = []
    edges: List[EdgeRec] = []
    # track special types to detect duplicates
    special_seen = {"initial": 0, "prep": 0, "error": 0}
    # counter for auto-naming plain '#final' occurrences (if any)
    final_plain_counter = 0

    def ensure_system(kind: str, utterance: str) -> NodeRec:
        raw = norm(kind)
        utt = norm(utterance)

        # default
        key = "UNKNOWN"
        kind_field = "other"

        if raw:
            if raw.startswith('#'):
                token = raw[1:]
                tkl = token.lower()

                # '#final_' prefix -> normalize to 'final' display, keep distinct key
                if tkl.startswith('final_'):
                    key = token  # e.g. 'final_state1'
                    kind_field = 'final'

                # plain '#final' -> create a unique internal key so multiple plain
                # '#final' instances don't collapse. Use final_plain_counter.
                elif tkl == 'final':
                    nonlocal final_plain_counter
                    final_plain_counter += 1
                    key = f"final_auto_{final_plain_counter}"
                    kind_field = 'final'

                # special singletons: initial/prep/error -> treat as named kinds
                elif tkl in special_seen:
                    key = token
                    kind_field = token

                else:
                    key = token
                    kind_field = token
            else:
                # does not start with '#': treat as other (keep key distinct)
                key = raw
                kind_field = 'other'
        else:
            key = 'UNKNOWN'
            kind_field = 'other'

        # If utterance is the special skip marker, force kind_field to 'skip'
        if utt == '[$skip]':
            kind_field = 'skip'

        if key in system_by_kind:
            n = system_by_kind[key]
            existing_utt = norm(str(n.fields.get("utterance", "")))
            new_utt = utt

            # If existing utterance is empty, fill it and accept as same node
            if not existing_utt and utterance:
                n.fields["utterance"] = utterance
                return n

            # If utterances match (including both empty), treat as same node
            if existing_utt == new_utt:
                return n

            # Same state but different system utterance -> duplicate error
            raise ValueError(
                f"Duplicate system node for state '{raw}' (key='{key}'): existing utterance='{existing_utt}' vs new='{utterance}'"
            )

        node = NodeRec(
            id=str(uuid.uuid4()),
            short_id=generate_short_id(),
            x=0.0,
            y=float(len(system_by_kind)) * 10.0,  # temporary; will be overwritten by auto_layout
            text="システム",
            type=NODE_TYPE_SYSTEM,
            fields={"node_kind": kind_field, "utterance": utterance or ""},
        )
        system_by_kind[key] = node
        return node

    # N = len(data_rows)
    N = 100

    for i, r in enumerate(data_rows):
        state = cell_str(r, hidx["state"])
        sys_utt = cell_str(r, hidx["system utterance"])
        user_utt = cell_str(r, hidx["user utterance example"])
        user_type = cell_str(r, hidx["user utterance type"])
        cond = cell_str(r, hidx["conditions"])
        actions = cell_str(r, hidx["actions"])
        next_state = cell_str(r, hidx["next state"])


        sys_in = ensure_system(state, sys_utt)
        sys_out = ensure_system(next_state, "") if next_state else None

        # If user-related cells are all empty AND there's no next_state,
        # then this row only contributes a system (already ensured above).
        # If user-related cells are empty but next_state exists, create a
        # direct edge from sys_in -> sys_out to preserve the transition.
        if (user_utt + user_type + cond + actions + next_state) == "":
            # Priority: top row should be highest (not used since no user node)
            if sys_out is not None:
                edges.append(EdgeRec(from_id=sys_in.id, to_id=sys_out.id))
            continue

        # Priority: top row should be highest
        pr = str(N - 10 * i)

        u = NodeRec(
            id=str(uuid.uuid4()),
            short_id=generate_short_id(),
            x=0.0,
            y=float(i),  # temporary; will be overwritten by auto_layout
            text="ユーザ",
            type=NODE_TYPE_USER,
            fields={
                "priority": pr,
                "utterance_example": user_utt,
                "utterance_type": user_type,
                "condition": cond,
                "action": actions,
            },
        )
        user_nodes.append(u)

        edges.append(EdgeRec(from_id=sys_in.id, to_id=u.id))
        if sys_out is not None:
            edges.append(EdgeRec(from_id=u.id, to_id=sys_out.id))

    # Build nodes dict for layout
    nodes_by_id: Dict[str, NodeRec] = {}
    for s in system_by_kind.values():
        nodes_by_id[s.id] = s
    for u in user_nodes:
        nodes_by_id[u.id] = u

    # === Apply auto layout positions here ===
    auto_layout_positions(nodes_by_id, edges)

    # Output JSON
    nodes_out: List[Dict[str, Any]] = []
    for n in nodes_by_id.values():
        nodes_out.append(
            {
                "id": n.id,
                "short_id": n.short_id,
                "x": n.x,
                "y": n.y,
                "text": n.text,
                "type": n.type,
                **n.fields,
            }
        )

    edges_out: List[Dict[str, str]] = []
    for e in edges:
        edges_out.append(
            {
                "from": e.from_id,
                "to": e.to_id,
                "from_conn": e.from_conn,
                "to_conn": e.to_conn,
            }
        )

    return {"nodes": nodes_out, "edges": edges_out}


def main():
    ap = argparse.ArgumentParser(description="Convert scenario.xlsx to state_graph.json")
    ap.add_argument("xlsx_path", nargs="?", default="scenario.xlsx", help="Input XLSX path (default: scenario.xlsx)")
    ap.add_argument("-o", "--out", default="state_graph.json", help="Output JSON path (default: state_graph.json)")
    args = ap.parse_args()

    xlsx_path = Path(args.xlsx_path)
    out_path = Path(args.out)

    graph = make_state_graph_from_xlsx(xlsx_path)
    out_path.write_text(json.dumps(graph, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"OK: {out_path.resolve()}  (nodes={len(graph['nodes'])}, edges={len(graph['edges'])})")


if __name__ == "__main__":
    main()
