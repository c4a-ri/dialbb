# scenario_converter.py
# Export JSON (state_graph.json) -> scenario.xlsx converter
#
# Columns mapping (requested):
#  - state                  -> System「ノードタイプ」(node_kind)
#  - system utterance        -> System「発話」(utterance)
#  - user utterance example  -> empty
#  - user utterance type     -> User「発話タイプ」(utterance_type)
#  - conditions              -> User「遷移の条件」(condition)
#  - actions                 -> empty
#  - next state              -> Systemノードの「ノードタイプ(node_kind)の表示文字列」

from __future__ import annotations

import argparse
import json
import random
import string
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple

from openpyxl import Workbook
from openpyxl.utils import get_column_letter


NODE_TYPE_SYSTEM = "system"
NODE_TYPE_USER = "user"

HEADERS = [
    "flag",
    "state",
    "system utterance",
    "user utterance example",
    "user utterance type",
    "conditions",
    "actions",
    "next state",
]


@dataclass(frozen=True)
class Node:
    node_id: str
    node_type: str
    text: str
    fields: Dict[str, Any]

    def get(self, key: str, default: str = "") -> str:
        v = self.fields.get(key, default)
        if v is None:
            return default
        return str(v)


@dataclass(frozen=True)
class Edge:
    from_id: str
    to_id: str


def generate_short_id(length: int = 6) -> str:
    chars = string.ascii_uppercase + string.digits
    return "".join(random.choices(chars, k=length))


def load_graph(json_path: Path) -> Tuple[Dict[str, Node], List[Edge]]:
    data = json.loads(json_path.read_text(encoding="utf-8"))

    nodes: Dict[str, Node] = {}
    for n in data.get("nodes", []):
        node_id = n.get("id", "")
        node_type = n.get("type", "")
        text = n.get("text", "")
        fields = dict(n)
        for k in ["id", "x", "y", "text", "type", "short_id"]:
            fields.pop(k, None)

        if node_id:
            nodes[node_id] = Node(node_id=node_id, node_type=node_type, text=text, fields=fields)

    edges: List[Edge] = []
    for e in data.get("edges", []):
        a = e.get("from")
        b = e.get("to")
        if a and b:
            edges.append(Edge(from_id=a, to_id=b))

    return nodes, edges


def build_index(nodes: Dict[str, Node], edges: List[Edge]):
    """incoming/outgoing adjacency lists by node_id"""
    incoming: Dict[str, List[str]] = {nid: [] for nid in nodes.keys()}
    outgoing: Dict[str, List[str]] = {nid: [] for nid in nodes.keys()}

    for e in edges:
        if e.from_id in outgoing:
            outgoing[e.from_id].append(e.to_id)
        if e.to_id in incoming:
            incoming[e.to_id].append(e.from_id)

    return incoming, outgoing


def system_node_kind_text(sys_node: Node) -> str:
    """Systemノードの「ノードタイプ」(node_kind) の表示文字列"""
    k = str(sys_node.get("node_kind", "") or "").strip()
    if not k:
        return ""
    # If already has leading '#', keep as-is
    if k.startswith("#"):
        return k

    lk = k.lower()
    # Add leading '#' for: any string starting with 'final' (e.g. 'final', 'final_state*'),
    # and exact prep/initial/error
    if lk.startswith("final") or lk in ("prep", "initial", "error"):
        return "#" + k

    return k


def system_state_value(sys_node: Node) -> str:
    """
    Excel の "state" に入れる値（要件: system「ノードタイプ」）
    """
    return system_node_kind_text(sys_node)


def system_utterance_value(sys_node: Node) -> str:
    return sys_node.get("utterance", "")


def user_utterance_example_value(user_node: Node) -> str:
    return user_node.get("utterance_example", "")


def user_utterance_type_value(user_node: Node) -> str:
    return user_node.get("utterance_type", "")


def user_condition_value(user_node: Node) -> str:
    return user_node.get("condition", "")


def user_priority_value(user_node: Node) -> int:
    """Userノードの優先度（大きいほど上に並べる）"""
    try:
        return int(user_node.get("priority", "0") or 0)
    except ValueError:
        return 0


def generate_rows(nodes: Dict[str, Node], edges: List[Edge]) -> List[List[str]]:
    """
    1行 = (incoming System) -> User -> (outgoing System)

    - 行の並び順は User の priority 降順（大きいほど上）
    - System->User が複数、User->System が複数のときは組み合わせ分だけ行を作る
    - どちらかが無い場合も、空セルで1行は出す（編集途中でもExcel化できる）
    """
    incoming, outgoing = build_index(nodes, edges)

    rows: List[List[str]] = []
    # track system nodes that were emitted as part of user rows
    included_system_ids = set()

    # Prepare display names for system nodes. For nodes whose node_kind == 'final'
    # we must assign unique names '#final_stateN' (N starts from 1) per node.
    system_display: Dict[str, str] = {}
    final_counter = 0
    other_counter = 0
    for n in [nn for nn in nodes.values() if nn.node_type == NODE_TYPE_SYSTEM]:
        nk = str(n.get('node_kind', '') or '').strip()
        if nk == 'final':
            final_counter += 1
            system_display[n.node_id] = f"#final_state{final_counter}"
        elif nk == 'other':
            other_counter += 1
            system_display[n.node_id] = f"other{other_counter}"
        else:
            system_display[n.node_id] = system_node_kind_text(n)

    # User ノードを起点に行を作る（priority 降順）
    user_nodes = [n for n in nodes.values() if n.node_type == NODE_TYPE_USER]
    user_nodes.sort(key=user_priority_value, reverse=True)

    for u in user_nodes:
        # incoming systems: System -> this User
        inc_systems: List[Node] = []
        for src_id in incoming.get(u.node_id, []):
            src = nodes.get(src_id)
            if src and src.node_type == NODE_TYPE_SYSTEM:
                inc_systems.append(src)

        # outgoing systems: this User -> System
        out_systems: List[Node] = []
        for dst_id in outgoing.get(u.node_id, []):
            dst = nodes.get(dst_id)
            if dst and dst.node_type == NODE_TYPE_SYSTEM:
                out_systems.append(dst)

        if not inc_systems:
            inc_systems = [None]  # type: ignore
        if not out_systems:
            out_systems = [None]  # type: ignore

        for s_in in inc_systems:
            for s_out in out_systems:
                flag = ""  # 現状は空
                state = system_display[s_in.node_id] if s_in else ""
                sys_utt = system_utterance_value(s_in) if s_in else ""
                user_ex = user_utterance_example_value(u)
                user_type = user_utterance_type_value(u)
                cond = user_condition_value(u)
                actions = ""  # 現状は空
                next_state = system_display[s_out.node_id] if s_out else ""
                rows.append([flag, state, sys_utt, user_ex, user_type, cond, actions, next_state])
                # mark included system nodes so we can emit standalone systems later
                if s_in:
                    included_system_ids.add(s_in.node_id)
                if s_out:
                    included_system_ids.add(s_out.node_id)

    # Emit standalone system-only rows for systems not covered by any user rows
    for sys_node in [n for n in nodes.values() if n.node_type == NODE_TYPE_SYSTEM]:
        state_val = system_display.get(sys_node.node_id, system_node_kind_text(sys_node))

        if not any(r[1] == state_val for r in rows):
            flag = ""
            sys_utt = system_utterance_value(sys_node)
            rows.append([flag, state_val, sys_utt, "", "", "", "", ""])
        # if sys_node.node_id not in included_system_ids:
        #     flag = ""
        #     state = system_state_value(sys_node)
        #     sys_utt = system_utterance_value(sys_node)
        #     rows.append([flag, state, sys_utt, "", "", "", "", ""])
        #     included_system_ids.add(sys_node.node_id)

    return rows





def write_xlsx(rows: List[List[str]], out_path: Path):
    wb = Workbook()
    ws = wb.active
    ws.title = "scenario"

    # header
    ws.append(HEADERS)

    # data rows
    for r in rows:
        ws.append(r)

    # simple column sizing
    for col_idx, header in enumerate(HEADERS, start=1):
        max_len = len(header)
        for row_idx in range(2, ws.max_row + 1):
            v = ws.cell(row=row_idx, column=col_idx).value
            if v is None:
                continue
            max_len = max(max_len, len(str(v)))
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max(12, max_len + 2), 60)

    # freeze header
    ws.freeze_panes = "A2"

    wb.save(out_path)


def main():
    ap = argparse.ArgumentParser(description="Convert state_graph.json to scenario.xlsx")
    ap.add_argument("json_path", nargs="?", default="state_graph.json", help="Input JSON path (default: state_graph.json)")
    ap.add_argument("-o", "--out", default="scenario.xlsx", help="Output XLSX path (default: scenario.xlsx)")
    args = ap.parse_args()

    json_path = Path(args.json_path)
    out_path = Path(args.out)

    nodes, edges = load_graph(json_path)
    rows = generate_rows(nodes, edges)
    write_xlsx(rows, out_path)

    print(f"OK: {out_path.resolve()}  (rows={len(rows)})")


if __name__ == "__main__":
    main()
