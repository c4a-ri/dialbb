#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Copyright 2025 C4A Research Institute, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# config_editor.py
#   edit configuration
#   コンフィギュレーションの編集

__version__ = "0.1"
__author__ = "Mikio Nakano"

import os
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
import ruamel.yaml
from typing import Any, Dict, List

from dialbb.no_code.gui_utils import child_position, gui_text
from dialbb.util.logger import get_logger


logger = get_logger(__name__)


# -------- config.yml編集の管理するクラス -------------------------------------
class ConfigManager:
    def __init__(self, file_path: str, template_path: str) -> None:
        self.yaml = ruamel.yaml.YAML()
        self.file_path = file_path
        self.yaml.indent(sequence=4, offset=2)

        try:
            with open(file_path, encoding="utf-8") as file:
                self.config = self.yaml.load(file)
        except (FileNotFoundError, IOError, ruamel.yaml.YAMLError):
            logger.exception("can't read config file: %s", file_path)

        # read dst descriptions from templates
        self.block_dst: Dict[str, Dict[str, Any]] = {}
        for language in ("ja", "en"):
            block_config_file = os.path.join(template_path, "blocks", "dst.yml")
            try:
                with open(block_config_file, encoding="utf-8") as fp:
                    dst_config: Dict[str, Any] = self.yaml.load(fp)
            except (FileNotFoundError, IOError, ruamel.yaml.YAMLError):
                logger.exception(
                    "can't read template config file: %s.", block_config_file
                )
                dst_config = {}
            self.block_dst[language] = dst_config

        # self.yaml.dump(self.config, sys.stdout)

    # blocksのblock要素を取得
    def get_block(self, name: str) -> Dict[str, Any]:
        result = {}
        for block in self.config.get("blocks", []):
            if block.get("name") == name:
                result = block
                # logger.debug(f'### block data: {block}')
        return result

    # whether to use DST block
    def if_use_dst(self) -> bool:

        return True if self.get_block("dst") else False

    def get_llm_model(self) -> str:
        result = ""
        # managerのchatgptモデルを参照
        llm_desc = self.get_block("manager").get("llm")
        if llm_desc:
            result = llm_desc.get("model", "")
        return result

    # ChatGPTのsituation, persona, cautionsを取得
    def get_prompt_elements(self, name) -> str:
        result = ""
        llm_desc: Dict[str, Any] = self.get_block("manager").get("llm")
        if llm_desc:
            result = llm_desc.get(name)
        if result:
            return "\n".join(result)
        else:
            return ""

    # get block descriptions to add
    def get_fixed_element(self, block_name: str) -> Dict[str, Any]:
        lang = self.config.get("language", "")

        if block_name == "dst":
            result: Dict[str, Any] = self.block_dst[lang]
        else:
            raise Exception("no such block: " + block_name)

        return result

    # add/del block config
    def change_block_ele(self, op: str, name: str) -> None:

        target_index = -1

        block_descs: List[Dict[str, Any]] = self.config["blocks"]
        for idx in range(len(block_descs)):
            if block_descs[idx].get("name") == name:
                target_index = idx
                break
        if target_index >= 0:
            if op == "del":
                del block_descs[target_index]
        elif op == "add":
            block_descs.insert(-1, self.get_fixed_element(name))

    # ChatGPT blockの編集
    def set_dst(self, kind: str) -> None:
        if kind == "use":
            self.change_block_ele("add", "dst")
        elif kind == "not_use":
            self.change_block_ele("del", "dst")

    def set_llm_model(self, model: str) -> None:
        if not model:
            return
        # understanderのchatgptモデル設定
        dst_block = self.get_block("dst")
        if dst_block:
            dst_block["model"] = model

        # managerのchatgptモデル設定
        self.get_block("manager")["llm"]["model"] = model

    # situationの設定
    def set_llm_list(self, label: str, data: str) -> None:
        llm = self.get_block("manager").get("llm")
        if llm and data:
            # リストにして空行削除
            llm[label] = [a for a in data.split("\n") if a != ""]

    # config.ymlへ書き込み
    def write(self) -> None:
        with open(self.file_path, mode="w", encoding="utf-8") as file:
            self.yaml.dump(self.config, stream=file)

    def print(self) -> None:
        self.yaml.dump(self.config, sys.stdout)


# アプリConfig編集の処理
def edit_app_config(parent, file_path, template_path, settings):

    config_manager = ConfigManager(file_path, template_path)

    # 編集画面を表示
    sub_menu = tk.Toplevel(parent)
    sub_menu.title(gui_text("conf_edt_title"))
    sub_menu.grab_set()  # モーダルにする
    sub_menu.focus_set()  # フォーカスを新しいウィンドウをへ移す
    sub_menu.transient(parent)
    # サイズ＆表示位置の指定
    parent_x = (
        parent.winfo_rootx() + parent.winfo_width() // 4 - sub_menu.winfo_width() // 2
    )
    parent_y = (
        parent.winfo_rooty()
        + parent.winfo_height() // 10
        - sub_menu.winfo_height() // 2
    )
    sub_menu.geometry(f"400x600+{parent_x}+{parent_y}")

    # DST Frameを作成
    dst_fr = ttk.Labelframe(
        sub_menu,
        text=gui_text("conf_edt_dst"),
        padding=(10),
        style="My.TLabelframe",
    )
    dst_fr.pack(expand=True, fill=tk.Y, padx=5, pady=5)

    # LLM Radio Button
    dst_val = tk.StringVar()
    dst_val.set("use" if config_manager.if_use_dst() else "not_use")
    dst_rb1 = ttk.Radiobutton(
        dst_fr, text=gui_text("btn_yes"), value="use", variable=dst_val
    )
    dst_rb2 = ttk.Radiobutton(
        dst_fr, text=gui_text("btn_no"), value="not_use", variable=dst_val
    )
    dst_rb1.grid(column=0, row=0, padx=5, pady=5)
    dst_rb2.grid(column=1, row=0, padx=5, pady=5)

    # LLMManager Frameを作成
    llm_mng_fr = ttk.Labelframe(
        sub_menu,
        text=gui_text("conf_edt_llm"),
        padding=(10),
        style="My.TLabelframe",
    )
    # ウィンドウ幅に合わせて横方向にも広がるようにする
    llm_mng_fr.pack(expand=True, fill=tk.BOTH, padx=5, pady=5)
    # ［ChatGPTモデル］プルダウンメニュー
    label1 = tk.Label(llm_mng_fr, text=gui_text("conf_edt_model"))
    models = settings.get_llm_models()
    if not models:
        # default設定
        models = [
            "gpt-4o",
            "gpt-4o-mini",
            "gpt-5.4-mini",
            "gpt-5.4",
            "google_genai:gemini-3-flash",
            "google_genai:gemini-2.5-flash",
            "google_genai:gemini-2.5-flash-lite",
            "anthropic:claude-haiku-4-5"
        ]
    v = tk.StringVar()
    combobox = ttk.Combobox(
        llm_mng_fr,
        textvariable=v,
        values=models,
        state="normal",
        style="office.TCombobox",
    )
    # combobox.bind('<<ComboboxSelected>>', select_combo)

    label1.grid(column=0, row=1)
    # combobox.grid(column=1, row=1, columnspan=2, padx=5, pady=5)
    combobox.grid(column=1, row=1, padx=5, pady=5, sticky=tk.EW)

    # モデル候補の編集ボタンを追加
    other_model_button = ttk.Button(
        llm_mng_fr,
        text=gui_text("btn_add"),
        # width=10,
        command=lambda: llm_model_edit(sub_menu, settings),
    )
    other_model_button.grid(column=2, row=1, padx=5)

    # situation入力エリア
    label2 = tk.Label(llm_mng_fr, text=gui_text("conf_edt_situation"))
    stt = scrolledtext.ScrolledText(llm_mng_fr, wrap=tk.NONE, width=24, height=6)
    # 横方向のスクロールバーを作成
    horiz_scrollbar1 = tk.Scrollbar(llm_mng_fr, orient=tk.HORIZONTAL, command=stt.xview)
    stt.config(xscrollcommand=horiz_scrollbar1.set)
    # configの値を設定
    stt.insert(0.0, config_manager.get_prompt_elements("situation"))
    label2.grid(column=0, row=2)
    stt.grid(column=1, row=2, columnspan=2, sticky=tk.NSEW, padx=5, pady=5)
    horiz_scrollbar1.grid(column=1, row=3, columnspan=2, sticky=tk.NSEW)

    # persona入力エリア
    label2 = tk.Label(llm_mng_fr, text=gui_text("conf_edt_persona"))
    psn = scrolledtext.ScrolledText(llm_mng_fr, wrap=tk.NONE, width=24, height=6)
    # 横方向のスクロールバーを作成
    horiz_scrollbar2 = tk.Scrollbar(llm_mng_fr, orient=tk.HORIZONTAL, command=psn.xview)
    psn.config(xscrollcommand=horiz_scrollbar2.set)
    # configの値を設定
    psn.insert(0.0, config_manager.get_prompt_elements("persona"))
    # ラベルを作成
    label2.grid(column=0, row=4)
    psn.grid(column=1, row=4, columnspan=2, sticky=tk.NSEW, padx=5, ipady=8)
    horiz_scrollbar2.grid(column=1, row=5, columnspan=2, sticky=tk.NSEW, padx=5)

    # cautions入力エリア
    label2 = tk.Label(llm_mng_fr, text=gui_text("conf_edt_cautions"))
    ctn = scrolledtext.ScrolledText(llm_mng_fr, wrap=tk.NONE, width=24, height=6)
    # 横方向のスクロールバーを作成
    horiz_scrollbar3 = tk.Scrollbar(llm_mng_fr, orient=tk.HORIZONTAL, command=ctn.xview)
    ctn.config(xscrollcommand=horiz_scrollbar3.set)
    # configの値を設定
    ctn.insert(0.0, config_manager.get_prompt_elements("cautions"))
    # ラベルを作成
    label2.grid(column=0, row=6)
    ctn.grid(column=1, row=6, columnspan=2, sticky=tk.NSEW, padx=5, ipady=3)
    horiz_scrollbar3.grid(column=1, row=7, columnspan=2, sticky=tk.NSEW, padx=5)

    llm_mng_fr.grid_columnconfigure(1, weight=1)
    llm_mng_fr.grid_rowconfigure(2, weight=1)
    llm_mng_fr.grid_rowconfigure(4, weight=1)
    llm_mng_fr.grid_rowconfigure(6, weight=1)

    # OKボタン
    ok_btn = ttk.Button(
        sub_menu, text=gui_text("btn_ok"), command=lambda: ok_btn_click()
    )
    # Cancelボタン
    cancel_btn = ttk.Button(
        sub_menu, text=gui_text("btn_cancel"), command=lambda: cancel_btn_click()
    )

    # ウィンドウが表示された後に実行される処理を設定
    sub_menu.bind("<Map>", lambda event: on_window_shown())

    # Layout
    dst_fr.pack(fill=tk.X, padx=5, pady=5)
    llm_mng_fr.pack(fill=tk.BOTH, padx=5, pady=5)
    cancel_btn.pack(side="right", padx=5, pady=5)
    ok_btn.pack(side="right", padx=5, pady=5)
    # central_position(sub_menu, width=250, height=130)  # サイズ＆表示位置の指定

    # ウィンドウが表示された後にコンボボックスの値を設定する
    def on_window_shown():
        model = config_manager.get_llm_model()
        if model in models:
            combobox.current(newindex=models.index(model))

    # GPTモデル候補の編集処理
    def llm_model_edit(parent, settings):
        sub_menu = tk.Toplevel(parent)
        sub_menu.title("GPT models")
        sub_menu.grab_set()  # モーダルにする
        sub_menu.focus_set()  # フォーカスを新しいウィンドウをへ移す
        sub_menu.transient(parent)
        # サイズ＆表示位置の指定
        child_position(parent, sub_menu)

        # GPTモデル候補入力エリア
        label1 = tk.Label(sub_menu, text=gui_text("conf_edt_model"))
        mdl = scrolledtext.ScrolledText(sub_menu, wrap=tk.NONE, width=24, height=6)
        # configの値を設定
        mdl.insert(0.0, ("\n").join(combobox["values"]))

        # Button
        ok_btn = ttk.Button(
            sub_menu, text=gui_text("btn_ok"), command=lambda: ok_click()
        )
        can_btn = ttk.Button(
            sub_menu,
            text=gui_text("btn_cancel"),
            command=lambda: cancel_click(sub_menu),
        )

        # Layout
        label1.pack(side="left", padx=2, pady=2)
        mdl.pack(padx=1, pady=5)
        can_btn.pack(side="right", padx=5, pady=5)
        ok_btn.pack(side="right", padx=5, pady=5)

        # ボタンクリックされた際のイベント
        def ok_click():
            # プルダウンリストを変更
            in_data = mdl.get(1.0, tk.END)
            models = [a for a in in_data.split("\n") if a != ""]
            combobox["values"] = models

            # LLMモデル候補の登録
            settings.set_llm_models(models)
            # 画面を閉じる
            sub_menu.destroy()

        # [cancel]ボタン：自ウィンドウを閉じる
        def cancel_click(frame):
            # 画面を閉じる
            frame.destroy()

    # ボタンクリックの処理
    def ok_btn_click():
        # ウジェットの設定値を取得
        if_use_dst = dst_val.get()
        model = combobox.get()
        situation = stt.get(1.0, tk.END)
        persona = psn.get(1.0, tk.END)
        cautions = ctn.get(1.0, tk.END)

        # change config data (overwrite even if there's no change)
        config_manager.set_dst(if_use_dst)
        config_manager.set_llm_model(model)
        config_manager.set_llm_list("situation", situation)
        config_manager.set_llm_list("persona", persona)
        config_manager.set_llm_list("cautions", cautions)

        # write config.yml
        config_manager.write()
        config_manager.print()

        # 画面を閉じる
        sub_menu.destroy()

    def cancel_btn_click():
        # 画面を閉じる
        sub_menu.destroy()


# 自動テストConfig編集の処理
def edit_test_config(parent, file_path: str, settings) -> None:
    # simulation config を直接読み込み
    yaml = ruamel.yaml.YAML()
    yaml.indent(sequence=4, offset=2)
    logger.debug("read config file: %s", file_path)

    try:
        with open(file_path, encoding="utf-8") as file:
            config = yaml.load(file)
    except (FileNotFoundError, IOError):
        logger.exception("can't read config file: %s.", file_path)
        return

    # file_pathよりファイル名のみ抽出
    template_content = ""
    config_settings = config.get("settings", "")
    if config_settings:
        template_name = config_settings[0].get("prompt_template", "")

        # file_pathのfile_nameをtemplate_nameに置き換えてtemplateファイルのパスを生成
        template_path = file_path.replace(os.path.basename(file_path), template_name)
        # テキストファイルを読み込む
        try:
            with open(template_path, encoding="utf-8") as file:
                template_content = file.read()
        except (FileNotFoundError, IOError):
            logger.exception("can't read template file: %s.", template_path)
        logger.debug("template_name: %s", template_name)

    # 編集画面を表示
    sub_menu = tk.Toplevel(parent)
    sub_menu.title(gui_text("conf_edt_title"))
    sub_menu.grab_set()
    sub_menu.focus_set()
    sub_menu.transient(parent)

    # サイズ＆表示位置の指定
    parent_x = (
        parent.winfo_rootx() + parent.winfo_width() // 4 - sub_menu.winfo_width() // 2
    )
    parent_y = (
        parent.winfo_rooty()
        + parent.winfo_height() // 10
        - sub_menu.winfo_height() // 2
    )
    sub_menu.geometry(f"500x380+{parent_x}+{parent_y}")

    # ChatGPT Manager Frame
    gpt_mng_fr = ttk.Labelframe(
        sub_menu,
        text=gui_text("conf_edt_simulation"),
        padding=(10),
        style="My.TLabelframe",
    )
    # テスト用ダイアログでも横方向に広げる
    gpt_mng_fr.pack(expand=True, fill=tk.BOTH, padx=5, pady=5)

    # ChatGPTモデル プルダウンメニュー
    label1 = tk.Label(gpt_mng_fr, text=gui_text("conf_edt_model"))
    models = settings.get_llm_models()
    if not models:
        # default設定
        models = [
            "gpt-4o",
            "gpt-4o-mini",
            "gpt-5.4-mini",
            "gpt-5.4",
            "google_genai:gemini-3-flash",
            "google_genai:gemini-2.5-flash",
            "google_genai:gemini-2.5-flash-lite",
            "anthropic:claude-haiku-4-5"
        ]
    current_model = config.get("model", "")
    if current_model and current_model not in models:
        # 現在のモデルが候補に無い場合は先頭に追加
        models.insert(0, current_model)

    # コンボボックス用は current_model を初期値として一度だけ設定
    selected_val = tk.StringVar()
    combobox = ttk.Combobox(
        gpt_mng_fr,
        textvariable=selected_val,
        values=models,
        state="normal",
        style="office.TCombobox",
    )

    # max_turns用テキストフィールド
    label_max_turns = tk.Label(gpt_mng_fr, text=gui_text("conf_edt_max_turns"))
    max_turns_var = tk.StringVar()
    current_max_turns = str(config.get("max_turns", ""))
    max_turns_var.set(current_max_turns)
    entry_max_turns = tk.Entry(gpt_mng_fr, textvariable=max_turns_var, width=10)

    # ウィンドウが表示された後に実行される処理を設定
    sub_menu.bind("<Map>", lambda event: on_window_shown())

    label1.grid(column=0, row=1)
    combobox.grid(column=1, row=1, padx=5, pady=5, sticky=tk.W)
    label_max_turns.grid(column=0, row=2, sticky=tk.W)
    entry_max_turns.grid(column=1, row=2, padx=5, pady=5, sticky=tk.W)


    # prompt_template編集エリア
    label2 = tk.Label(gpt_mng_fr, text=gui_text("conf_edt_prompt"))
    stt = scrolledtext.ScrolledText(gpt_mng_fr, wrap=tk.NONE, width=36, height=16)
    horiz_scrollbar1 = tk.Scrollbar(gpt_mng_fr, orient=tk.HORIZONTAL, command=stt.xview)
    stt.config(xscrollcommand=horiz_scrollbar1.set)
    # テンプレート内容を表示
    stt.insert(0.0, template_content)
    label2.grid(column=0, row=3)
    stt.grid(column=1, row=3, columnspan=2, sticky=tk.NSEW, padx=5, pady=5)
    horiz_scrollbar1.grid(column=1, row=4, columnspan=2, sticky=tk.NSEW)


    gpt_mng_fr.grid_columnconfigure(1, weight=1)
    gpt_mng_fr.grid_rowconfigure(2, weight=1)
    gpt_mng_fr.grid_rowconfigure(3, weight=1)
    gpt_mng_fr.grid_rowconfigure(4, weight=1)

    # OK/Cancel ボタン
    ok_btn = ttk.Button(
        sub_menu, text=gui_text("btn_ok"), command=lambda: ok_btn_click()
    )
    cancel_btn = ttk.Button(
        sub_menu, text=gui_text("btn_cancel"), command=lambda: cancel_btn_click()
    )

    cancel_btn.pack(side="right", padx=5, pady=5)
    ok_btn.pack(side="right", padx=5, pady=5)

    # ウィンドウが表示された後にコンボボックスの値を設定する

    def on_window_shown():
        combobox.current(newindex=models.index(current_model))
        entry_max_turns.delete(0, tk.END)
        entry_max_turns.insert(0, current_max_turns)

    # ボタンクリックの処理

    def ok_btn_click():
        gpt_model = combobox.get()
        prompt = stt.get(1.0, tk.END)
        max_turns_val = entry_max_turns.get()

        # YAML に設定を反映
        if config:
            config["model"] = gpt_model
            # max_turnsが空でなければintで保存、空なら削除
            if max_turns_val.strip():
                try:
                    config["max_turns"] = int(max_turns_val)
                except ValueError:
                    config["max_turns"] = max_turns_val  # 数値でなければそのまま保存
            elif "max_turns" in config:
                del config["max_turns"]

        # ファイルに書き込み
        logger.info("write config file: %s", file_path)
        with open(file_path, mode="w", encoding="utf-8") as file:
            yaml.dump(config, stream=file)

        # ファイルに書き込み
        logger.info("write template file: %s", template_path)
        with open(template_path, mode="w", encoding="utf-8") as file:
            file.write(prompt)

        sub_menu.destroy()

    def cancel_btn_click():
        sub_menu.destroy()
